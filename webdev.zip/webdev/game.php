<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
		<link rel="stylesheet" href="../webdev/navbar.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
        <title>Game</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap');
            *{
                margin: 0;
                padding: 0;
            }
            body{
                background-repeat: no-repeat;
                background-size: cover;
                background-image: linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),url(nature.jpg);
                overflow: hidden;
            }
            .logoutbtn{
                background-color: transparent;
                border: none;
                color: white;
                width: auto;
                font-size: 15px;
                font-family: 'Inter Tight', sans-serif;
            }
            .logoutbtn:hover{
                text-shadow: 0 0 5px #FF0000;
                font-weight: bold;
                border-bottom: 2px solid;
            }
            .bodybox{
                width: 100vw;
                height: 90vh;
                display: inline-flex;
                justify-content: space-evenly;
                align-items: center;
                flex-direction: row;
            }
            .bodybox a{
                text-decoration: none;
            }
            .iden1{
                width: 30vw;
                height: 50vh;
                backdrop-filter: blur(10px);
                box-shadow: 0 0 10px;
                border-radius: 20px;
                font-family: 'Poppins', sans-serif;
                font-size: 25px;
                letter-spacing: 5px;
            }
            .titlegame{
                width: 100%;
                height: 100%; 
                display: grid;
                place-items: center;
                color: white;
                text-shadow: 0 0 5px black;
            }
            .diff{
                width: 100%;
                height: 30%;
                display: flex;
                justify-content: space-evenly;
                align-items: center;
            }
            .diff button{
                width: 100px;
                height: 50px;
                background-color: #2F3C7E;
                border: none;
                border-radius: 40px;
                color: white;
                font-family: 'Poppins', sans-serif;
                font-size: 15px;
                letter-spacing: 2px;
            }
            .diff button:hover{
                font-size: 17px;
                color: black;
                background-color: #FBEAEB;
            }
        </style>
    </head>
    <body>
        <nav>
            <div class="logotitle">
                <a href="../webdev/index.php"><image class="image" src="atom-loader.gif"></a>
                <a href="../webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
            </div>
            <div class="menu">
                <ul>
                    <li><a href="../webdev/index.php">Home</a></li>
                    <li><a href="../webdev/game.php">Games</a></li>
                </ul>
            </div>
        </nav>
        <div class="bodybox">
            <div class="iden1"><a href="../webdev/games/World Scramble /Landing.html">
                <div class="titlegame">Jumbled Letters</div>
            </div></a>
            <div class="iden1"><a href="../webdev/games/QuizLevels/index.html"
>                <div class="titlegame">Multiple Choice</div>
            </div></a>
            <div class="iden1"><a href="../webdev/games/4pics1word/Home.html">
                <div class="titlegame">4 Pics 1 Word</div>
            </div></a>
        </div>
    </body>
</html>
