const gameOverSound = document.getElementById("gameOverSound");

const questions = [
    {
        question: "What is the chemical symbol for oxygen?",
        answers: [
            { text: "O", correct: true },
            { text: "Ox", correct: false },
            { text: "Oy", correct: false },
            { text: "Ol", correct: false }
        ],
    },
    {
        question: "Which element has the atomic number 26?",
        answers: [
            { text: "Iron (Fe)", correct: true },
            { text: "Silver (Ag)", correct: false },
            { text: "Sodium (Na)", correct: false },
            { text: "Carbon (C)", correct: false }
        ],
    },
    {
        question: "What is the name of the group of elements found in Group 18 of the periodic table?",
        answers: [
            { text: "Halogens", correct: false },
            { text: "Alkali Metals", correct: false },
            { text: " Noble Gases", correct: true },
            { text: "Lanthanides", correct: false }
        ],
    },
    {
        question: "Which element is commonly used to inflate balloons and make your voice sound funny when inhaled in small quantities?",
        answers: [
            { text: "Neon (Ne)", correct: false },
            { text: "Helium (He)", correct: true },
            { text: "Argon (Ar)", correct: false },
            { text: "Krypton (Kr)", correct: false }
        ],
    },
    {
        question: "The element with the atomic number 1 is also known as?",
        answers: [
            { text: "Oxygen (O)", correct: false },
            { text: "Helium (He)", correct: false },
            { text: "Hydrogen (H)", correct: true },
            { text: "Neon (Ne)", correct: false }
        ],
    },
    {
        question: "Which element is a necessary component of the ozone layer in the Earth's atmosphere?",
        answers: [
            { text: "Oxygen", correct: true },
            { text: "Nitrogen", correct: false },
            { text: "Chlorine", correct: false },
            { text: "Carbon", correct: false }
        ],
    },
    {
        question: "What is the chemical symbol for lead?",
        answers: [
            { text: "Li", correct: false },
            { text: "Ld", correct: false },
            { text: "Pb", correct: true },
            { text: "Le", correct: false }
        ],
    },
    {
        question: "Which element is the main constituent of Earth's atmosphere?",
        answers: [
            { text: "Carbon", correct: false },
            { text: "Oxygen", correct: false },
            { text: "Nitrogen", correct: true },
            { text: "Hydrogen", correct: false }
        ],
    },
    {
        question: "What is the chemical symbol for silver?",
        answers: [
            { text: "Ag", correct: true },
            { text: "Si", correct: false },
            { text: "Sg", correct: false },
            { text: "Sl", correct: false }
        ],
    },
    {
        question: "Which element is often used in batteries and is symbolized by Zn?",
        answers: [
            { text: "Zirconite", correct: false },
            { text: "Zircon", correct: false },
            { text: "Zirconium", correct: false },
            { text: "Zinc", correct: true }
        ],
    }
]

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function shuffleQuestions(questions) {
    questions.forEach(question => {
        shuffleArray(question.answers);
    });

    shuffleArray(questions);
}

shuffleQuestions(questions);

questions.forEach((question, index) => {
    console.log(`Question ${index + 1}: ${question.question}`);
    question.answers.forEach((answer, i) => {
        console.log(`  ${i + 1}. ${answer.text}`);
    });
    console.log();
});

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const hearts = document.querySelectorAll(".heart");
let currentQuestionIndex = 0;
let score = 0;
let lives = 3;

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    lives = 3;
    updateHearts();
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if (isCorrect) {
        selectedBtn.classList.add("correct");
        score++;
    } else {
        selectedBtn.classList.add("incorrect");
        lives--;
        setTimeout(updateHearts, 100);
        if (lives === 0) {
            playGameOverSound();
            showScore();
            return;
        }
    }

    Array.from(answerButtons.children).forEach(button => {
        if (button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
}

function playGameOverSound() {
    gameOverSound.play();
}

function updateHearts() {
    hearts.forEach((heart, index) => {
        if (index < lives) {
            heart.style.display = "inline";
        } else {
            heart.style.display = "none";
        }
    });
}

function showScore() {
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Play Again";
    nextButton.style.display = "block";

    nextButton.addEventListener("click", () => {
        window.location.href = "index.html";
    });
}


function handleNextButton() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
}

nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length) {
        handleNextButton();
    } else {
        startQuiz();
    }
});

startQuiz();