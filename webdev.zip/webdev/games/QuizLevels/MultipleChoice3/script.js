const gameOverSound = document.getElementById("gameOverSound");

const questions = [
    {
        question: "Which element, used in nuclear reactors and not found in nature, has the atomic number 94?",
        answers: [
            { text: "Plutonium", correct: true },
            { text: "Polonium", correct: false },
            { text: "Protactinium", correct: false },
            { text: "Palladium", correct: false }
        ],
    },
    {
        question: "What element has the highest atomic number and was synthesized in a laboratory for the first time in 2006?",
        answers: [
            { text: "Darmstadtium", correct: false },
            { text: "Rutherfordium", correct: false },
            { text: "Ununoctium", correct: true },
            { text: "Livermorium", correct: false }
        ],
    },
    {
        question: "Which radioactive element is used in cancer treatments and has the chemical symbol Ra?",
        answers: [
            { text: "Rhodium", correct: false },
            { text: "Rubidium", correct: false },
            { text: "Radon", correct: false },
            { text: "Radium", correct: true }
        ],
    },
    {
        question: "What is the only element in the periodic table that is a liquid at room temperature?",
        answers: [
            { text: "Bromine", correct: false },
            { text: "Mercury", correct: true },
            { text: "Gallium", correct: false },
            { text: "Francium", correct: false }
        ],
    },
    {
        question: "Which element, used in nuclear reactors as a neutron moderator, has the atomic number 5?",
        answers: [
            { text: "Boron", correct: false },
            { text: "Beryllium", correct: false },
            { text: "Lithium", correct: true },
            { text: "Helium", correct: false }
        ],
    },
    {
        question: "What rare-earth element is named after the capital of Norway and is used in the production of strong permanent magnets?",
        answers: [
            { text: "Europium", correct: true },
            { text: "Yttrium", correct: false },
            { text: "Neodymium", correct: false },
            { text: "Scandium", correct: false }
        ],
    },
    {
        question: "Which element is critical for the functioning of the thyroid gland and has the chemical symbol I?",
        answers: [
            { text: "Iodine", correct: true },
            { text: "Iron", correct: false },
            { text: "Indium", correct: false },
            { text: "Irridium", correct: false }
        ],
    },
    {
        question: "Which element, with the atomic number 90, is found in uranium ores and is highly radioactive?",
        answers: [
            { text: "Francium", correct: false },
            { text: "Radium", correct: false },
            { text: "Radon", correct: false },
            { text: "Thorium", correct: true }
        ],
    },
    {
        question: "What element, essential for plant growth, is often added to fertilizers and has the chemical symbol K?",
        answers: [
            { text: "Palladium", correct: false },
            { text: "Phosphorus", correct: false },
            { text: "Potassium", correct: true },
            { text: "Promethium", correct: false }
        ],
    },
    {
        question: "Which element, used in the aerospace industry and as a catalyst in chemical reactions, has the atomic number 77?",
        answers: [
            { text: "Rhenium", correct: true },
            { text: "Iridium", correct: false },
            { text: "Osmium", correct: false },
            { text: "Ruthenium", correct: false }
        ],
    }
]

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function shuffleQuestions(questions) {
    questions.forEach(question => {
        shuffleArray(question.answers);
    });

    shuffleArray(questions);
}

shuffleQuestions(questions);

questions.forEach((question, index) => {
    console.log(`Question ${index + 1}: ${question.question}`);
    question.answers.forEach((answer, i) => {
        console.log(`  ${i + 1}. ${answer.text}`);
    });
    console.log();
});

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const hearts = document.querySelectorAll(".heart");
let currentQuestionIndex = 0;
let score = 0;
let lives = 3;

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    lives = 3;
    updateHearts();
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if (isCorrect) {
        selectedBtn.classList.add("correct");
        score++;
    } else {
        selectedBtn.classList.add("incorrect");
        lives--;
        setTimeout(updateHearts, 100);
        if (lives === 0) {
            playGameOverSound();
            showScore();
            return;
        }
    }

    Array.from(answerButtons.children).forEach(button => {
        if (button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
}

function playGameOverSound() {
    gameOverSound.play();
}

function updateHearts() {
    hearts.forEach((heart, index) => {
        if (index < lives) {
            heart.style.display = "inline";
        } else {
            heart.style.display = "none";
        }
    });
}

function showScore() {
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Play Again";
    nextButton.style.display = "block";

    nextButton.addEventListener("click", () => {
        window.location.href = "index.html";
    });
}


function handleNextButton() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
}

nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length) {
        handleNextButton();
    } else {
        startQuiz();
    }
});

startQuiz();