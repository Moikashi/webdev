const gameOverSound = document.getElementById("gameOverSound");

const questions = [
    {
        question: "Which element is known for its radioactive properties and is used in nuclear reactors and atomic bombs?",
        answers: [
            { text: "Uranium", correct: true },
            { text: "Mercury", correct: false },
            { text: "Aluminum", correct: false },
            { text: "Oxygen", correct: false }
        ],
    },
    {
        question: "What is the most abundant element in Earth's crust?",
        answers: [
            { text: "Iron", correct: false },
            { text: "Silicon", correct: false },
            { text: "Oxygen", correct: true },
            { text: "Gold", correct: false }
        ],
    },
    {
        question: "Which noble gas is often used in helium-filled balloons to make them float?",
        answers: [
            { text: "Neon", correct: false },
            { text: "Argon", correct: false },
            { text: "Helium", correct: true },
            { text: "Krypton", correct: false }
        ],
    },
    {
        question: "Which element has the chemical symbol Fe and is commonly found in red blood cells, enabling them to transport oxygen?",
        answers: [
            { text: "Iron", correct: true },
            { text: "Iodine", correct: false },
            { text: "Flourine", correct: false },
            { text: "Silver", correct: false }
        ],
    },
    {
        question: "What is the lightest element in the periodic table?",
        answers: [
            { text: "Hydrogen", correct: true },
            { text: "Helium", correct: false },
            { text: "Lithium", correct: false },
            { text: "Boron", correct: false }
        ],
    },
    {
        question: "Which element, often used in electronics, has the atomic number 14 and is known for its semiconducting properties?",
        answers: [
            { text: "Carbon", correct: false },
            { text: "Silicon", correct: true },
            { text: "Alluminum", correct: false },
            { text: "Titanium", correct: false }
        ],
    },
    {
        question: "Which element is commonly used in fluorescent lights, has the atomic number 18, and is a noble gas?",
        answers: [
            { text: "Krypton", correct: true },
            { text: "Xenon", correct: false },
            { text: "Neon", correct: false },
            { text: "Argon", correct: false }
        ],
    },
    {
        question: "Which element is a major component of Earth's atmosphere and is essential for respiration?",
        answers: [
            { text: "Nitrogen", correct: true },
            { text: "Carbon", correct: false },
            { text: "Sulfur", correct: false },
            { text: "Chlorine", correct: false }
        ],
    },
    {
        question: "Which element is a key component of the Earth's inner core and has the atomic number 26?",
        answers: [
            { text: "Gold", correct: false },
            { text: "Copper", correct: false },
            { text: "Zinc", correct: false },
            { text: "Iron", correct: true }
        ],
    },
    {
        question: "Which element, with the chemical symbol is known for its excellent electrical conductivity and is commonly used in wiring and electrical components?",
        answers: [
            { text: "Cobalt", correct: false },
            { text: "Chromium", correct: false },
            { text: "Copper", correct: true },
            { text: "Cesium", correct: false }
        ],
    }
]

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function shuffleQuestions(questions) {
    questions.forEach(question => {
        shuffleArray(question.answers);
    });

    shuffleArray(questions);
}

shuffleQuestions(questions);

questions.forEach((question, index) => {
    console.log(`Question ${index + 1}: ${question.question}`);
    question.answers.forEach((answer, i) => {
        console.log(`  ${i + 1}. ${answer.text}`);
    });
    console.log();
});

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const hearts = document.querySelectorAll(".heart");
let currentQuestionIndex = 0;
let score = 0;
let lives = 3;

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    lives = 3;
    updateHearts();
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}

function resetState() {
    nextButton.style.display = "none";
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if (isCorrect) {
        selectedBtn.classList.add("correct");
        score++;
    } else {
        selectedBtn.classList.add("incorrect");
        lives--;
        setTimeout(updateHearts, 100);
        if (lives === 0) {
            playGameOverSound();
            showScore();
            return;
        }
    }

    Array.from(answerButtons.children).forEach(button => {
        if (button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
}

function playGameOverSound() {
    gameOverSound.play();
}

function updateHearts() {
    hearts.forEach((heart, index) => {
        if (index < lives) {
            heart.style.display = "inline";
        } else {
            heart.style.display = "none";
        }
    });
}

function showScore() {
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Play Again";
    nextButton.style.display = "block";

    // Add the following lines to redirect to the specified file path
    nextButton.addEventListener("click", () => {
        window.location.href = "index.html";
    });
}


function handleNextButton() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
}

nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length) {
        handleNextButton();
    } else {
        startQuiz();
    }
});

startQuiz();