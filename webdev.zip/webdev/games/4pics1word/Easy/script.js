const levels = [
    {  
        pics: ["aluminum/PTE ALUMINUM 1.jpg", "aluminum/PTE ALUMINUM 2.jpg", "aluminum/PTE ALUMINUM 3.jpg", "aluminum/PTE ALUMINUM 4.jpg"],
        correctWord: "aluminum"
    },
    {
        pics: ["oxygen/PTE OXYGEN 1.jpg", "oxygen/PTE OXYGEN 2.jpg", "oxygen/PTE OXYGEN 3.jpg", "oxygen/PTE OXYGEN 4.jpg"],
        correctWord: "oxygen"
    },
    {
        pics: ["calcium/PTE CALCIUM 1.jpg", "calcium/PTE CALCIUM 2.jpg", "calcium/PTE CALCIUM 3.jpg", "calcium/PTE CALCIUM 4.jpg"],
        correctWord: "calcium"
    },
    {
        pics: ["carbon/PTE CARBON 1.jpg", "carbon/PTE CARBON 2.jpg", "carbon/PTE CARBON 3.jpg", "carbon/PTE CARBON 4.jpg"],
        correctWord: "carbon"
    },
    {
        pics: ["helium/PTE HELIUM 1.jpg", "helium/PTE HELIUM 2.jpg", "helium/PTE HELIUM 3.jpg", "helium/PTE HELIUM 4.jpg"],
        correctWord: "helium"
    },
     {
        pics: ["hydrogen/PTE Hydrogen 1.jpg", "hydrogen/PTE Hydrogen 2.jpg", "hydrogen/PTE Hydrogen 3.jpg", "hydrogen/PTE Hydrogen 4.jpg"],
        correctWord: "hydrogen"
    },
    {
        pics: ["magnesium/PTE MAGNESIUM 1.jpg", "magnesium/PTE MAGNESIUM 2.jpg", "magnesium/PTE MAGNESIUM 3.jpg", "magnesium/PTE MAGNESIUM 4.jpg"],
        correctWord: "magnesium"
    },
     {
        pics: ["mercury/PTE MERCURY 1.jpg", "mercury/PTE MERCURY 2.jpg", "mercury/PTE MERCURY 3.jpg", "mercury/PTE MERCURY 4.jpg"],
        correctWord: "mercury"
    },
    {
        pics: ["nitrogen/PTE NITROGEN 1.jpg", "nitrogen/PTE NITROGEN 2.jpg", "nitrogen/PTE NITROGEN 3.jpg", "nitrogen/PTE NITROGEN 4.jpg"],
        correctWord: "nitrogen"
    },
    {
        pics: ["sodium/PTE SODIUM 1.jpg", "sodium/PTE SODIUM 2.jpg", "sodium/PTE SODIUM 3.jpg", "sodium/PTE SODIUM 4.jpg"],
        correctWord: "sodium"
    },
    // Add more levels as needed
];

const heartsContainer = document.querySelector('.hearts');
const hearts = heartsContainer.querySelectorAll('.heart');
let remainingHearts = hearts.length;

let currentLevel = 0;
let lives = 3;
let score = 0;
let wrongAnswersCount = 0; // Counter for wrong answers

function displayCurrentLevel() {
    const picsContainer = document.getElementById("image-container");
    picsContainer.innerHTML = ""; // Clear previous level's pictures
    
    const currentLevelData = levels[currentLevel];
    
    for (const pic of currentLevelData.pics) {
        const img = document.createElement("img");
        img.src = pic;
        picsContainer.appendChild(img);
    }
}

function loseHeart() {
    remainingHearts--;
    updateHearts();

    if (remainingHearts === 0) {
        // All hearts are lost, show game over screen
        gameOver();
    } else {
        // Reset the timer to 30 seconds
        timeRemaining = 30;
        initGame();
    }
}

function updateHearts() {
    for (let i = 0; i < hearts.length; i++) {
        if (i < remainingHearts) {
            hearts[i].textContent = '❤️';
        } else {
            hearts[i].textContent = '🖤';
        }
    }
}

function checkAnswer() {
    const userGuess = document.getElementById("checkanswer").value.toLowerCase();
    const resultContainer = document.getElementById("result");
    const currentLevelData = levels[currentLevel];

    if (userGuess === currentLevelData.correctWord) {
        resultContainer.textContent = "Correct! Move on to the next level.";
        currentLevel++;
        score++;

        if (currentLevel === levels.length) {
            resultContainer.textContent = "Congratulations! You completed all levels.";
        } else {
            displayCurrentLevel();
        }
    } else {
        lives--;

        if (lives === 0) {
            resultContainer.textContent = `Game over🥺, Score: ${score}`;
            gameOver();
        } else {
            resultContainer.textContent = `Incorrect. Try again. Lives left: ${lives}`;
            loseHeart();

            // Increment the wrong answers count
            wrongAnswersCount++;

            // Check if the maximum wrong answers limit is reached
            if (wrongAnswersCount >= 3) {
                gameOver();
            }
        }
    }
}

function gameOver() {
    const gameOverOverlay = document.querySelector('.game-over-overlay');
    const finalScoreElement = document.getElementById('final-score');
    finalScoreElement.textContent = Math.max(0, score);
    gameOverOverlay.style.display = 'flex';
}

function tryAgain() {
    currentLevel = 0;
    lives = 3;
    score = 0;
    remainingHearts = hearts.length;
    wrongAnswersCount = 0; // Reset wrong answers count
    const gameOverOverlay = document.querySelector('.game-over-overlay');
    gameOverOverlay.style.display = 'none';
    location.reload();
}

function exitGame() {
    window.location.href = '../home.html';
}

document.addEventListener("DOMContentLoaded", function() {
    displayCurrentLevel();
});