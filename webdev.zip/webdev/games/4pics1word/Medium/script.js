const levels = [
    {  
        pics: ["boron/PTE BORON 1.jpg", "boron/PTE BORON 2.jpg", "boron/PTE BORON 3.jpg", "boron/PTE BORON 4.jpg"],
        correctWord: "boron"
    },
    {
        pics: ["chlorine/PTE CHLORINE 1.jpg", "chlorine/PTE CHLORINE 2.jpg", "chlorine/PTE CHLORINE 3.jpg", "chlorine/PTE CHLORINE 4.jpg"],
        correctWord: "chlorine"
    },
    {
        pics: ["copper/PTE COPPER 1.jpg", "copper/PTE COPPER 2.jpg", "copper/PTE COPPER 3.jpg", "copper/PTE COPPER 4.jpg"],
        correctWord: "copper"
    },
    {
        pics: ["flourine/PTE FLOURINE 1.jpg", "flourine/PTE FLOURINE 2.jpg", "flourine/PTE FLOURINE 3.jpg", "flourine/PTE FLOURINE 4.jpg"],
        correctWord: "flourine"
    },
    {
        pics: ["gold/PTE GOLD1.jpg", "gold/PTE GOLD2.jpg", "gold/PTE GOLD3.jpg", "gold/PTE GOLD4.jpg"],
        correctWord: "gold"
    },
     {
        pics: ["iron/PTE IRON1.jpg", "iron/PTE IRON2.jpg", "iron/PTE IRON3.jpg", "iron/PTE IRON4.jpg"],
        correctWord: "iron"
    },
    {
        pics: ["nickel/PTE NICKEL1.jpg", "nickel/PTE NICKEL2.jpg", "nickel/PTE NICKEL3.jpg", "nickel/PTE NICKEL4.jpg"],
        correctWord: "nickel"
    },
     {
        pics: ["potassium/PTE POTASSIUM1.jpg", "potassium/PTE POTASSIUM2.jpg", "potassium/PTE POTASSIUM3.jpg", "potassium/PTE POTASSIUM4.jpg"],
        correctWord: "potassium"
    },
    {
        pics: ["sulfur/PTE SULFUR1.jpg", "sulfur/PTE SULFUR2.jpg", "sulfur/PTE SULFUR3.jpg", "sulfur/PTE SULFUR4.jpg"],
        correctWord: "sulfur"
    },
    {
        pics: ["zinc/PTE ZINC1.jpg", "zinc/PTE ZINC2.jpg", "zinc/PTE ZINC3.jpg", "zinc/PTE ZINC4.jpg"],
        correctWord: "zinc"
    },
    // Add more levels as needed
];

const heartsContainer = document.querySelector('.hearts');
const hearts = heartsContainer.querySelectorAll('.heart');
let remainingHearts = hearts.length;

let currentLevel = 0;
let lives = 3;
let score = 0;
let wrongAnswersCount = 0; // Counter for wrong answers

function displayCurrentLevel() {
    const picsContainer = document.getElementById("image-container");
    picsContainer.innerHTML = ""; // Clear previous level's pictures
    
    const currentLevelData = levels[currentLevel];
    
    for (const pic of currentLevelData.pics) {
        const img = document.createElement("img");
        img.src = pic;
        picsContainer.appendChild(img);
    }
}

function loseHeart() {
    remainingHearts--;
    updateHearts();

    if (remainingHearts === 0) {
        // All hearts are lost, show game over screen
        gameOver();
    } else {
        // Reset the timer to 30 seconds
        timeRemaining = 30;
        initGame();
    }
}

function updateHearts() {
    for (let i = 0; i < hearts.length; i++) {
        if (i < remainingHearts) {
            hearts[i].textContent = '❤️';
        } else {
            hearts[i].textContent = '🖤';
        }
    }
}

function checkAnswer() {
    const userGuess = document.getElementById("checkanswer").value.toLowerCase();
    const resultContainer = document.getElementById("result");
    const currentLevelData = levels[currentLevel];

    if (userGuess === currentLevelData.correctWord) {
        resultContainer.textContent = "Correct! Move on to the next level.";
        currentLevel++;
        score++;

        if (currentLevel === levels.length) {
            resultContainer.textContent = "Congratulations! You completed all levels.";
        } else {
            displayCurrentLevel();
        }
    } else {
        lives--;

        if (lives === 0) {
            resultContainer.textContent = `Game over🥺, Score: ${score}`;
            gameOver();
        } else {
            resultContainer.textContent = `Incorrect. Try again. Lives left: ${lives}`;
            loseHeart();

            // Increment the wrong answers count
            wrongAnswersCount++;

            // Check if the maximum wrong answers limit is reached
            if (wrongAnswersCount >= 3) {
                gameOver();
            }
        }
    }
}

function gameOver() {
    const gameOverOverlay = document.querySelector('.game-over-overlay');
    const finalScoreElement = document.getElementById('final-score');
    finalScoreElement.textContent = Math.max(0, score);
    gameOverOverlay.style.display = 'flex';
}

function tryAgain() {
    currentLevel = 0;
    lives = 3;
    score = 0;
    remainingHearts = hearts.length;
    wrongAnswersCount = 0; // Reset wrong answers count
    const gameOverOverlay = document.querySelector('.game-over-overlay');
    gameOverOverlay.style.display = 'none';
    location.reload();
}

function exitGame() {
    window.location.href = '../home.html';
}

document.addEventListener("DOMContentLoaded", function() {
    displayCurrentLevel();
});