const levels = [
    {  
        pics: ["valium/PTE VALIUM1.jpg", "valium/PTE VALIUM2.jpg", "valium/PTE VALIUM3.jpg", "valium/PTE VALIUM4.jpg"],
        correctWord: "valium" 
    },
    {
        pics: ["titanium/PTE TITANIUM1.jpg", "titanium/PTE TITANIUM2.jpg", "titanium/PTE TITANIUM3.jpg", "titanium/PTE TITANIUM4.jpg"],
        correctWord: "titanium"
    },
    {
        pics: ["terbium/PTE TERBIUM1.jpg", "terbium/PTE TERBIUM2.jpg", "terbium/PTE TERBIUM3.jpg", "terbium/PTE TERBIUM4.jpg"],
        correctWord: "terbium"
    },
    {
        pics: ["silicon/PTE SILICON1.jpg", "silicon/PTE SILICON2.jpg", "silicon/PTE SILICON3.jpg", "silicon/PTE SILICON4.jpg"],
        correctWord: "silicon"
    },
    {
        pics: ["samarium/PTE SAMARIUM1.jpg", "samarium/PTE SAMARIUM2.jpg", "samarium/PTE SAMARIUM3.jpg", "samarium/PTE SAMARIUM4.jpg"],
        correctWord: "samarium"
    },
     {
        pics: ["radium/PTE RADIUM1.jpg", "radium/PTE RADIUM2.jpg", "radium/PTE RADIUM3.jpg", "radium/PTE RADIUM4.jpg"],
        correctWord: "radium"
    },
    {
        pics: ["platinum/PTE PLATINUM1.jpg", "platinum/PTE PLATINUM2.jpg", "platinum/PTE PLATINUM3.jpg", "platinum/PTE PLATINUM4.jpg"],
        correctWord: "platinum"
    },
     {
        pics: ["lithium/PTE LITHIUM1.jpg", "lithium/PTE LITHIUM2.jpg", "lithium/PTE LITHIUM3.jpg", "lithium/PTE LITHIUM4.jpg"],
        correctWord: "lithium"
    },
    {
        pics: ["krypton/krypton 1.jpg", "krypton/krypton 2.png", "krypton/krypton 3.jpg", "krypton/krypton 4.jpg"],
        correctWord: "krypton"
    },
    {
        pics: ["cobalt/PTE COBALT1.jpg", "cobalt/PTE COBALT2.jpg", "cobalt/PTE COBALT3.jpg", "cobalt/PTE COBALT4.jpg"],
        correctWord: "cobalt"
    },
    // Add more levels as needed
];

const heartsContainer = document.querySelector('.hearts');
const hearts = heartsContainer.querySelectorAll('.heart');
let remainingHearts = hearts.length;

let currentLevel = 0;
let lives = 3;
let score = 0;
let wrongAnswersCount = 0; // Counter for wrong answers

function displayCurrentLevel() {
    const picsContainer = document.getElementById("image-container");
    picsContainer.innerHTML = ""; // Clear previous level's pictures
    
    const currentLevelData = levels[currentLevel];
    
    for (const pic of currentLevelData.pics) {
        const img = document.createElement("img");
        img.src = pic;
        picsContainer.appendChild(img);
    }
}

function loseHeart() {
    remainingHearts--;
    updateHearts();

    if (remainingHearts === 0) {
        // All hearts are lost, show game over screen
        gameOver();
    } else {
        // Reset the timer to 30 seconds
        timeRemaining = 30;
        initGame();
    }
}

function updateHearts() {
    for (let i = 0; i < hearts.length; i++) {
        if (i < remainingHearts) {
            hearts[i].textContent = '❤️';
        } else {
            hearts[i].textContent = '🖤';
        }
    }
}

function checkAnswer() {
    const userGuess = document.getElementById("checkanswer").value.toLowerCase();
    const resultContainer = document.getElementById("result");
    const currentLevelData = levels[currentLevel];

    if (userGuess === currentLevelData.correctWord) {
        resultContainer.textContent = "Correct! Move on to the next level.";
        currentLevel++;
        score++;

        if (currentLevel === levels.length) {
            resultContainer.textContent = "Congratulations! You completed all levels.";
        } else {
            displayCurrentLevel();
        }
    } else {
        lives--;

        if (lives === 0) {
            resultContainer.textContent = `Game over🥺, Score: ${score}`;
            gameOver();
        } else {
            resultContainer.textContent = `Incorrect. Try again. Lives left: ${lives}`;
            loseHeart();

            // Increment the wrong answers count
            wrongAnswersCount++;

            // Check if the maximum wrong answers limit is reached
            if (wrongAnswersCount >= 3) {
                gameOver();
            }
        }
    }
}

function gameOver() {
    const gameOverOverlay = document.querySelector('.game-over-overlay');
    const finalScoreElement = document.getElementById('final-score');
    finalScoreElement.textContent = Math.max(0, score);
    gameOverOverlay.style.display = 'flex';
}

function tryAgain() {
    currentLevel = 0;
    lives = 3;
    score = 0;
    remainingHearts = hearts.length;
    wrongAnswersCount = 0; // Reset wrong answers count
    const gameOverOverlay = document.querySelector('.game-over-overlay');
    gameOverOverlay.style.display = 'none';
    location.reload();
}

function exitGame() {
    window.location.href = '../home.html';
}

document.addEventListener("DOMContentLoaded", function() {
    displayCurrentLevel();
});