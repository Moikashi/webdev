let words = [
    {
        word: "Hydrogen",
        hint: "H"
    },
    {
        word: "Boron",
        hint: "B"
    },
    {
        word: "Carbon",
        hint: "C"
    },
    {
        word: "Aluminum",
        hint: "Al"
    },
    {
        word: "Silicon",
        hint: "Si"
    },
    {
        word: "Iron",
        hint: "Fe"
    },
    {
        word: "Cobalt",
        hint: "Co"
    },
    {
        word: "Gold",
        hint: "Au"
    },
    {
        word: "Platinum",
        hint: "Pt"
    },
    {
        word: "Barium",
        hint: "Ba"
    },
    {
        word: "Potassium",
        hint: "K"
    },
    {
        word: "Sodium",
        hint: "Na"
    },
    {
        word: "Magnesium",
        hint: "Mg"
    },
    {
        word: "Copper",
        hint: "Cu"
    },
    {
        word: "Zinc",
        hint: "Z"
    },
    {
        word: "Oxygen",
        hint: "O"
    },
];