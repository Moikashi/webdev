document.addEventListener('DOMContentLoaded', function() {
    const animatedContainer = document.getElementById('animated');
    const letters = animatedContainer.querySelectorAll('span');

    function animateLetters() {
        letters.forEach((letter, index) => {
            setTimeout(() => {
                letter.classList.add('wave');
            }, index * 100); // Add 3 seconds delay for each letter
        });

        // Wait for all letters to finish, then restart animation
        setTimeout(() => {
            letters.forEach((letter) => {
                letter.classList.remove('wave');
            });
            animateLetters();
        }, (letters.length + 1) * 500); // Add extra 3 seconds for the full cycle
    }

    animateLetters();
});


function toggleDifficult() {
    const difficultDiv = document.querySelector('.difficult');
    difficultDiv.classList.toggle('show');
}