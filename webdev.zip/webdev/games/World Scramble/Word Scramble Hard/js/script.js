const wordText = document.querySelector(".word");
const hintText = document.querySelector(".hint span");
const timeText = document.querySelector(".time b");
const inputField = document.querySelector("input");
const checkBtn = document.querySelector(".check-word");

const hearts = document.querySelectorAll('.heart');
const finalScoreElement = document.getElementById('final-score');
const scoreElement = document.getElementById('score');
const backToGameButton = document.getElementById('Try-Again');
const exitGameButton = document.getElementById('exit-game');
const gameOverOverlay = document.querySelector('.game-over-overlay');

const stageClearOverlay = document.querySelector('.stage-clear-overlay');
const stageClearScoreElement = document.getElementById('stage-clear-score');
const backToGameStageClearButton = document.getElementById('back-to-game-stage-clear');

const pauseButton = document.getElementById('Pause');
const gamePauseOverlay = document.querySelector('.game-pause-overlay');
const exitGamePauseButton = document.getElementById('exit-game1');
const resumeButton = document.getElementById('Resume');

let correctWord, timer;
let score = 0;
let timeRemaining = 30; // Add a variable to store the remaining time
let remainingHearts = 3; // Set the initial number of hearts
let questionsAnsweredCorrectly = 0; // Track the number of correct answers
const scoreThreshold = 16; // Set the score threshold for the "Completion Stage"

let isPaused = false;

const initTimer = maxTime => {
    clearInterval(timer);

    timer = setInterval(() => {
        if (maxTime > 0) {
            maxTime--;
            timeText.innerText = maxTime < 10 ? '0' + maxTime : maxTime; // Display leading zero for single-digit seconds
        } else {
            clearInterval(timer);
            alert(`Time's up! ${correctWord.toUpperCase()} was the correct word`);
            loseHeart();
            initGame();
        }
    }, 1000);
}

const initGame = () => {
    if (remainingHearts === 0 || questionsAnsweredCorrectly === words.length) {
        gameOver();
        return;
    }

    initTimer(timeRemaining);
    let randomIndex = Math.floor(Math.random() * words.length);
    let randomObj = words[randomIndex];
    words.splice(randomIndex, 1); // Remove the question from the array
    let wordArray = randomObj.word.split("");
    for (let i = wordArray.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [wordArray[i], wordArray[j]] = [wordArray[j], wordArray[i]];
    }
    wordText.innerText = wordArray.join("");
    hintText.innerText = randomObj.hint;
    correctWord = randomObj.word.toLowerCase();
    inputField.value = "";
    inputField.maxLength = "100", correctWord.length; // Set the maximum length
}

const checkWord = () => {
    let userWord = inputField.value.toLowerCase();
    if (!userWord) return alert("Please enter the word to check!");

    if (userWord !== correctWord) {
        alert(`Oops! ${userWord} is not the correct word`);
        loseHeart();
    } else {
        score++;
        scoreElement.textContent = score;

        if (score >= scoreThreshold && words.length > 0) {
            // Score reached the threshold and there are more questions
            showCompletionStage();
        } else if (remainingHearts === 0 || words.length === 0) {
            // All questions answered correctly or no more questions, trigger the game over state
            gameOver();
        } else {
            initGame();
        }
    }
}

function loseHeart() {
    remainingHearts--;
    updateHearts();

    if (remainingHearts === 0 || questionsAnsweredCorrectly === scoreThreshold || questionsAnsweredCorrectly === words.length) {
        gameOver();
    } else {
        // Reset the timer to 30 seconds
        timeRemaining = 30;
        initGame();
    }
}

function updateHearts() {
    for (let i = 0; i < hearts.length; i++) {
        if (i < remainingHearts) {
            hearts[i].textContent = '❤️';
        } else {
            hearts[i].textContent = '🖤';
        }
    }
}

function gameOver() {
    checkBtn.disabled = true;
    if (remainingHearts === 0) {
        showGameOverScreen();
    } else {
        showCompletionStage();
    }
}
// Function to check if any overlay is currently visible
function isOverlayVisible() {
    return (
        gamePauseOverlay.style.display === 'flex' ||
        gameOverOverlay.style.display === 'flex' ||
        stageClearOverlay.style.display === 'flex'
    );
}

function showPauseOverlay() {
    gamePauseOverlay.style.display = 'flex';
    isPaused = true;
}

function hidePauseOverlay() {
    gamePauseOverlay.style.display = 'none';
    isPaused = false;
}

function showGameOverScreen() {
    finalScoreElement.textContent = score; // Set the final score
    gameOverOverlay.style.display = 'flex';
}

function showCompletionStage() {
    stageClearScoreElement.textContent = score; // Set the score
    stageClearOverlay.style.display = 'flex';
}

// Function to check if the game is in the completion stage
function isInCompletionStage() {
    return stageClearOverlay.style.display === 'flex';
}

// Event listener for "Back to Game" button in the stage clear screen
backToGameStageClearButton.addEventListener('click', () => {
    stageClearOverlay.style.display = 'none'; // Fix typo
    location.reload();
});

// Event listener for "Back to Game" button in the stage clear screen
backToGameButton.addEventListener('click', () => {
    stageClearOverlay.style.display = 'none'; // Fix typo
    location.reload(); // Restart the game
});

inputField.addEventListener('keydown', function(event) {
    if (!isOverlayVisible() && event.key === 'Enter') {
        checkWord(); // Call the checkWord function when Enter is pressed and not in the overlay
        event.preventDefault(); // Prevent default Enter key behavior
    }
});

// Event listener for "Exit Game" button
exitGameButton.addEventListener('click', () => {
    // You can perform any exit action here, such as closing the game window or tab
    // For example, you can use window.close() to close the current window
    window.location.href ='Landing.html';
})

exitGamePauseButton.addEventListener('click', () => {
    // You can perform any exit action here, such as closing the game window or tab
    // For example, you can use window.close() to close the current window
 window.location.href = 'Landing.html';
})



// Event listener for "Pause" button
pauseButton.addEventListener('click', () => {
    if (!isPaused) {
        timeRemaining = parseInt(timeText.innerText); // Store the remaining time
        clearInterval(timer); // Stop the timer
        showPauseOverlay();
    }
});

// Event listener for "Resume" button in the pause overlay
resumeButton.addEventListener('click', () => {
    hidePauseOverlay();
    initTimer(timeRemaining); // Resume the timer with the remaining time
});

initGame();
checkBtn.addEventListener("click", checkWord);