<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
		<link rel="stylesheet" href="../webdev/navbar.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
        <style>
            body{
                background-repeat: no-repeat;
                background-size: cover;
                background-image: url(nature.jpg);
                background-image: linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)),url(nature.jpg);
                overflow: hidden;
            }
            .tablebox{
                width: 100vw;
                max-height: calc(100vh - 80px);
                height: 100vh;
                display: grid;
                place-items: center;
            }
            .table{
                border-collapse: separate;
                border-spacing: 1px;
                empty-cells: hide;
                border: 2px;
                width: 85vw;
                height: 80Vh;
                padding: 8px;
            }
            th {
                padding: .2vmax;
                font-size: 1vw;
            }
            th button:hover{
                text-shadow: 0 0 20px white;
                cursor: pointer;
            }
            th a button{
                text-decoration: none;
                color: white;
                font-family: 'Inter Tight', sans-serif;
                backdrop-filter: blur(20px);
                box-shadow: 0 0 5px black;
            }
            .logoutbtn{
                background-color: transparent;
                border: none;
                color: white;
                width: auto;
                font-size: 15px;
                font-family: 'Inter Tight', sans-serif;
            }
            .logoutbtn:hover{
                text-shadow: 0 0 5px #FF0000;
                font-weight: bold;
                border-bottom: 2px solid;
            }
            th a button {
                width: 100%;
                height: 100%;
                padding: 0;
                margin: 0;
                box-sizing: border-box;
                cursor: pointer;
                font-weight: bold;
                font-size: 30px;
                border: 2px;
                border-radius: 5px;
                border-style: outset;
                text-shadow: 0 0 10px black;
            }
            .colorbox{
                position: absolute;
                display: flex;
                justify-content: space-between;
                height: 150px;
                width: 35%;
                left: 25vw;
                top: 15vh;
                font-family: 'Inter Tight', sans-serif;
            }
            .colorname1{
                width: 40%; 
                height: 100%;
                display: grid;
                font-size: 35px;
            }
            .colorname2{
                width: 40%; 
                height: 100%;
                display: grid;
                font-size: 35px;
            }

            .AlkaliMetals{
                color: #c29d12;
            }
            .AlkaliMetalsbtn{
                background-color: #c29d12;
            }
            .AlkalineEarthMetals{
                color: #e77e27;
            }
            .AlkalineEarthMetalsbtn{
                background-color: #e77e27;
            }
            .TransitionMetals{
                color: #2281bc;
            }
            .TransitionMetalsbtn{
                background-color: #2281bc;
            }
            .Halogens{
                color: #4ca5cf;
            }
            .Halogensbtn{
                background-color: #4ca5cf;
            }
            .NobleGases{
                color: #965ba5;
            }
            .NobleGasesbtn{
                background-color: #965ba5;
            }
            .Lanthanides{
                color: #ea4c3c;
            }
            .Lanthanidesbtn{
                background-color: #ea4c3c;
            }
            .Metalloids{
                color: #808d8f;
            }
            .Metalloidsbtn{
                background-color: #808d8f;
            }
            .Actinides{
                color: #50b849;
            }
            .Actinidesbtn{
                background-color: #50b849;
            }
            .Non-Metals{
                color: #d91b5c;
            }
            .Non-Metalsbtn{
                background-color: #d91b5c;
            }
            .OtherMetals{
                color: magenta;
            }
            .OtherMetalsbtn{
                background-color: magenta;
            }
            @media screen and (max-width: 1400px) {
                th button{
                    font-size: 15px;
                    font-weight: bolder;
                }
            }
            @media screen and (max-width: 900px) {
                th a button{
                    font-size: 10px;
                    font-weight: bolder;
                }
                body{
                    overflow: auto;
                }
                .colorbox{
                    width: 40%;
                    left: 23%;
                }
                .colorname1{
                    font-size: 30px;
                }
                .colorname2{
                    font-size: 30px;
                }
            }
        </style>
    </head>
    <body>
        <nav>
            <div class="logotitle">
                <a href="../webdev/index.php"><image class="image" src="atom-loader.gif"></a>
                <a href="../webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
            </div>
            <div class="menu">
                <ul>
                    <li><a href="../webdev/index.php">Home</a></li>
                    <li><a href="../webdev/game.php">Games</a></li>
                </ul>
            </div>
        </nav>
        <div class="colorbox">
            <div class="colorname1">
                <h6 class="AlkaliMetals">Alkali Metals</h6>
                <h6 class="AlkalineEarthMetals">Alkaline Earth Metals</h6>
                <h6 class="TransitionMetals">Transition Metals</h6>
                <h6 class="Halogens">Halogens</h6>
                <h6 class="NobleGases">Noble Gases</h6>
            </div>
            <div class="colorname2">
                <h6 class="Lanthanides">Lanthanides</h6>
                <h6 class="Metalloids">Metalloids</h6>
                <h6 class="Actinides">Actinides</h6>
                <h6 class="Non-Metals">Non-Metals</h6>
                <h6 class="OtherMetals">Other Metals</h6>
            </div>
        </div>

        <div class="tablebox">
        <table class="table">
            <tr>
                <th><a href="../webdev/info/1.php"><button class="Non-Metalsbtn">H</button></a></th>
                <th colspan="16"></th>
                <th><a href="../webdev/info/2.php"><button class="NobleGasesbtn">He</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/3.php"><button class="AlkaliMetalsbtn">Li</button></a></th>
                <th><a href="../webdev/info/4.php"><button class="AlkalineEarthMetalsbtn">Be</button></a></th>
                <th colspan="10"></th>
                <th><a href="../webdev/info/5.php"><button class="Metalloidsbtn">B</button></a></th>
                <th><a href="../webdev/info/6.php"><button class="Non-Metalsbtn">C</button></a></th>
                <th><a href="../webdev/info/7.php"><button class="Non-Metalsbtn">N</button></a></th>
                <th><a href="../webdev/info/8.php"><button class="Non-Metalsbtn">O</button></a></th>
                <th><a href="../webdev/info/9.php"><button class="Halogensbtn">F</button></a></th>
                <th><a href="../webdev/info/10.php"><button class="NobleGasesbtn">Ne</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/11.php"><button class="AlkaliMetalsbtn">Na</button></a></th>
                <th><a href="../webdev/info/12.php"><button class="AlkalineEarthMetalsbtn">Mg</button></a></th>
                <th colspan="10"></th>
                <th><a href="../webdev/info/13.php"><button class="OtherMetalsbtn">Al</button></a></th>
                <th><a href="../webdev/info/14.php"><button class="Metalloidsbtn">Si</button></a></th>
                <th><a href="../webdev/info/15.php"><button class="Non-Metalsbtn">P</button></a></th>
                <th><a href="../webdev/info/16.php"><button class="Non-Metalsbtn">S</button></a></th>
                <th><a href="../webdev/info/17.php"><button class="Halogensbtn">Cl</button></a></th>
                <th><a href="../webdev/info/18.php"><button class="NobleGasesbtn">Ar</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/19.php"><button class="AlkaliMetalsbtn">K</button></a></th>
                <th><a href="../webdev/info/20.php"><button class="AlkalineEarthMetalsbtn">Ca</button></a></th>
                <th><a href="../webdev/info/21.php"><button class="TransitionMetalsbtn">Sc</button></a></th>
                <th><a href="../webdev/info/22.php"><button class="TransitionMetalsbtn">Ti</button></a></th>
                <th><a href="../webdev/info/23.php"><button class="TransitionMetalsbtn">V</button></a></th>
                <th><a href="../webdev/info/24.php"><button class="TransitionMetalsbtn">Cr</button></a></th>
                <th><a href="../webdev/info/25.php"><button class="TransitionMetalsbtn">Mn</button></a></th>
                <th><a href="../webdev/info/26.php"><button class="TransitionMetalsbtn">Fe</button></a></th>
                <th><a href="../webdev/info/27.php"><button class="TransitionMetalsbtn">Co</button></a></th>
                <th><a href="../webdev/info/28.php"><button class="TransitionMetalsbtn">Ni</button></a></th>
                <th><a href="../webdev/info/29.php"><button class="TransitionMetalsbtn">Cu</button></a></th>
                <th><a href="../webdev/info/30.php"><button class="TransitionMetalsbtn">Zn</button></a></th>
                <th><a href="../webdev/info/31.php"><button class="OtherMetalsbtn">Ga</button></a></th>
                <th><a href="../webdev/info/32.php"><button class="Metalloidsbtn">Ge</button></a></th>
                <th><a href="../webdev/info/33.php"><button class="Metalloidsbtn">As</button></a></th>
                <th><a href="../webdev/info/34.php"><button class="Non-Metalsbtn">Se</button></a></th>
                <th><a href="../webdev/info/35.php"><button class="Halogensbtn">Br</button></a></th>
                <th><a href="../webdev/info/36.php"><button class="NobleGasesbtn">Kr</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/37.php"><button class="AlkaliMetalsbtn">Rb</button></a></th>
                <th><a href="../webdev/info/38.php"><button class="AlkalineEarthMetalsbtn">Sr</button></a></th>
                <th><a href="../webdev/info/39.php"><button class="TransitionMetalsbtn">Y</button></a></th>
                <th><a href="../webdev/info/40.php"><button class="TransitionMetalsbtn">Zr</button></a></th>
                <th><a href="../webdev/info/41.php"><button class="TransitionMetalsbtn">Nb</button></a></th>
                <th><a href="../webdev/info/42.php"><button class="TransitionMetalsbtn">Mo</button></a></th>
                <th><a href="../webdev/info/43.php"><button class="TransitionMetalsbtn">Tc</button></a></th>
                <th><a href="../webdev/info/44.php"><button class="TransitionMetalsbtn">Ru</button></a></th>
                <th><a href="../webdev/info/45.php"><button class="TransitionMetalsbtn">Rh</button></a></th>
                <th><a href="../webdev/info/46.php"><button class="TransitionMetalsbtn">Pd</button></a></th>
                <th><a href="../webdev/info/47.php"><button class="TransitionMetalsbtn">Ag</button></a></th>
                <th><a href="../webdev/info/48.php"><button class="TransitionMetalsbtn">Cd</button></a></th>
                <th><a href="../webdev/info/49.php"><button class="OtherMetalsbtn">In</button></a></th>
                <th><a href="../webdev/info/50.php"><button class="OtherMetalsbtn">Sn</button></a></th>
                <th><a href="../webdev/info/51.php"><button class="Metalloidsbtn">Sb</button></a></th>
                <th><a href="../webdev/info/52.php"><button class="Metalloidsbtn">Te</button></a></th>
                <th><a href="../webdev/info/53.php"><button class="Halogensbtn">I</button></a></th>
                <th><a href="../webdev/info/54.php"><button class="NobleGasesbtn">Xe</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/55.php"><button class="AlkaliMetalsbtn">Cs</button></a></th>
                <th><a href="../webdev/info/56.php"><button class="AlkalineEarthMetalsbtn">Ba</button></a></th>
                <th colspan="1"></th>
                <th><a href="../webdev/info/72.php"><button class="TransitionMetalsbtn">Hf</button></a></th>
                <th><a href="../webdev/info/73.php"><button class="TransitionMetalsbtn">Ta</button></a></th>
                <th><a href="../webdev/info/74.php"><button class="TransitionMetalsbtn">W</button></a></th>
                <th><a href="../webdev/info/75.php"><button class="TransitionMetalsbtn">Re</button></a></th>
                <th><a href="../webdev/info/76.php"><button class="TransitionMetalsbtn">Os</button></a></th>
                <th><a href="../webdev/info/77.php"><button class="TransitionMetalsbtn">Lr</button></a></th>
                <th><a href="../webdev/info/78.php"><button class="TransitionMetalsbtn">Pt</button></a></th>
                <th><a href="../webdev/info/79.php"><button class="TransitionMetalsbtn">Au</button></a></th>
                <th><a href="../webdev/info/80.php"><button class="TransitionMetalsbtn">Hg</button></a></th>
                <th><a href="../webdev/info/81.php"><button class="OtherMetalsbtn">Ti</button></a></th>
                <th><a href="../webdev/info/82.php"><button class="OtherMetalsbtn">Pb</button></a></th>
                <th><a href="../webdev/info/83.php"><button class="OtherMetalsbtn">Bi</button></a></th>
                <th><a href="../webdev/info/84.php"><button class="Metalloidsbtn">Po</button></a></th>
                <th><a href="../webdev/info/85.php"><button class="Halogensbtn">At</button></a></th>
                <th><a href="../webdev/info/86.php"><button class="NobleGasesbtn">Rn</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/87.php"><button class="AlkaliMetalsbtn">Fr</button></a></th>
                <th><a href="../webdev/info/88.php"><button class="AlkalineEarthMetalsbtn">Ra</button></a></th>
                <th colspan="1"></th>
                <th><a href="../webdev/info/104.php"><button class="TransitionMetalsbtn">Rf</button></a></th>
                <th><a href="../webdev/info/105.php"><button class="TransitionMetalsbtn">Db</button></a></th>
                <th><a href="../webdev/info/106.php"><button class="TransitionMetalsbtn">Sg</button></a></th>
                <th><a href="../webdev/info/107.php"><button class="TransitionMetalsbtn">Bh</button></a></th>
                <th><a href="../webdev/info/108.php"><button class="TransitionMetalsbtn">Hs</button></a></th>
                <th><a href="../webdev/info/109.php"><button class="TransitionMetalsbtn">Mt</button></a></th>
                <th><a href="../webdev/info/110.php"><button class="TransitionMetalsbtn">Ds</button></a></th>
                <th><a href="../webdev/info/111.php"><button class="TransitionMetalsbtn">Rg</button></a></th>
                <th><a href="../webdev/info/112.php"><button class="TransitionMetalsbtn">Cn</button></a></th>
                <th><a href="../webdev/info/113.php"><button class="OtherMetalsbtn">Nh</button></a></th>
                <th><a href="../webdev/info/114.php"><button class="OtherMetalsbtn">Fl</button></a></th>
                <th><a href="../webdev/info/115.php"><button class="OtherMetalsbtn">Mc</button></a></th>
                <th><a href="../webdev/info/116.php"><button class="OtherMetalsbtn">Lv</button></a></th>
                <th><a href="../webdev/info/117.php"><button class="Halogensbtn">Ts</button></a></th>
                <th><a href="../webdev/info/118.php"><button class="NobleGasesbtn">Og</button></a></th>
            </tr>
            <tr>
                <th></th>
            </tr>
            <tr>
                <th rowspan="2" colspan="2"></th>
                <th><a href="../webdev/info/57.php"><button class="Lanthanidesbtn">La</button></a></th>
                <th><a href="../webdev/info/58.php"><button class="Lanthanidesbtn">Ce</button></a></th>
                <th><a href="../webdev/info/59.php"><button class="Lanthanidesbtn">Pr</button></a></th>
                <th><a href="../webdev/info/60.php"><button class="Lanthanidesbtn">Nd</button></a></th>
                <th><a href="../webdev/info/61.php"><button class="Lanthanidesbtn">Pm</button></a></th>
                <th><a href="../webdev/info/62.php"><button class="Lanthanidesbtn">Sm</button></a></th>
                <th><a href="../webdev/info/63.php"><button class="Lanthanidesbtn">Eu</button></a></th>
                <th><a href="../webdev/info/64.php"><button class="Lanthanidesbtn">Gd</button></a></th>
                <th><a href="../webdev/info/65.php"><button class="Lanthanidesbtn">Tb</button></a></th>
                <th><a href="../webdev/info/66.php"><button class="Lanthanidesbtn">Dy</button></a></th>
                <th><a href="../webdev/info/67.php"><button class="Lanthanidesbtn">Ho</button></a></th>
                <th><a href="../webdev/info/68.php"><button class="Lanthanidesbtn">Er</button></a></th>
                <th><a href="../webdev/info/69.php"><button class="Lanthanidesbtn">Tm</button></a></th>
                <th><a href="../webdev/info/70.php"><button class="Lanthanidesbtn">Yb</button></a></th>
                <th><a href="../webdev/info/71.php"><button class="Lanthanidesbtn">Lu</button></a></th>
            </tr>
            <tr>
                <th><a href="../webdev/info/89.php"><button class="Actinidesbtn">Ac</button></a></th>
                <th><a href="../webdev/info/90.php"><button class="Actinidesbtn">Th</button></a></th>
                <th><a href="../webdev/info/91.php"><button class="Actinidesbtn">Pa</button></a></th>
                <th><a href="../webdev/info/92.php"><button class="Actinidesbtn">U</button></a></th>
                <th><a href="../webdev/info/93.php"><button class="Actinidesbtn">Np</button></a></th>
                <th><a href="../webdev/info/94.php"><button class="Actinidesbtn">Pu</button></a></th>
                <th><a href="../webdev/info/95.php"><button class="Actinidesbtn">Am</button></a></th>
                <th><a href="../webdev/info/96.php"><button class="Actinidesbtn">Cm</button></a></th>
                <th><a href="../webdev/info/97.php"><button class="Actinidesbtn">Bk</button></a></th>
                <th><a href="../webdev/info/98.php"><button class="Actinidesbtn">Cf</button></a></th>
                <th><a href="../webdev/info/99.php"><button class="Actinidesbtn">Es</button></a></th>
                <th><a href="../webdev/info/100.php"><button class="Actinidesbtn">Fm</button></a></th>
                <th><a href="../webdev/info/101.php"><button class="Actinidesbtn">Md</button></a></th>
                <th><a href="../webdev/info/102.php"><button class="Actinidesbtn">No</button></a></th>
                <th><a href="../webdev/info/103.php"><button class="Actinidesbtn">Lr</button></a></th>
            </tr>
        </table>
        </div>
    </body>
</html>
