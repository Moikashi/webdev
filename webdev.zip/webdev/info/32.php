
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>GERMANIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">32.</span>
            <span class="r-one">72.640</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Germanium">Ge</a>

            <hr class="h-line">
            <span class="e-name">GERMANIUM</span>
            <span class="n-m">(Metalloids)</span>
            <div class="info">
                <span>Atomic mass: 72.640 u</span>
                <span>Melting point: 938.25°C (1211.4 K)</span>
                <span>Boiling point: 2833°C (3106.15 K)</span>
                <span>Discovery date: 1886</span>
                <span>Discovered by: Clemens Winkler</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">GERMANIUM</span>
                <span class="first">Germanium is a chemical element with the symbol Ge and atomic number 32.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin germania for Germany. It was discovered and isolated by the German chemist Clemens-Alexander Winkler in 1886 in the mineral argyrodite (GeS2×4Ag2S). First proposed to exist by Dmitri Mendeleyev in 1871 based on gaps in his newly created Periodic Table of Elements, germanium was discovered by the German chemist Clemens Winkler in the mineral argyrodite (Ag8GeS6) in 1886. Today, germanium is primarily obtained from the smelting of zinc ores and from the byproducts of burning certain types of coal.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Pure germanium is a hard, lustrous, gray-white, brittle metalloid. It has a diamondlike crystalline structure and it is similar in chemical and physical properties to silicon. Germanium is stable in air and water, and is unaffected by alkalis and acids, except nitric acid.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>