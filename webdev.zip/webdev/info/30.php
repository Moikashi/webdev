
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>ZINC</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">30.</span>
            <span class="r-one">65.380</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Zinc">Zn</a>

            <hr class="h-line">
            <span class="e-name">ZINC</span>
            <span class="n-m">(Transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 65.380 u</span>
                <span>Melting point: 419.53°C (692.68 K)</span>
                <span>Boiling point: 907°C (1180.15 K)</span>
                <span>Discovery date: 1746</span>
                <span>Discovered by: Andreas Sigismund Marggraf</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">ZINC</span>
                <span class="first">Zinc is a chemical element with the symbol Zn and atomic number 30. Zinc is a slightly brittle metal at room temperature and has a shiny-greyish.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the German zink of unknown origin. It was first used in prehistoric times, where its compounds were used for healing wounds and sore eyes and for making brass. Zinc was recognized as a metal as early as 1374. Although zinc compounds have been used for at least 2,500 years in the production of brass, zinc wasn't recognized as a distinct element until much later. Metallic zinc was first produced in India sometime in the 1400s by heating the mineral calamine (ZnCO3) with wool. Zinc was rediscovered by Andreas Sigismund Marggraf in 1746 by heating calamine with charcoal. Today, most zinc is produced through the electrolysis of aqueous zinc sulfate (ZnSO4).</span>
                
                <span class="facts">FACTS</span>
                <span class="third">The primary use of zinc is in the galvanizing process, which protects iron and steel from rusting. Zinc can also be alloyed with other metals and used for die-casting into shapes such as door handles, alloyed with copper to make brass, and alloyed with copper and tin to make bronze.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>