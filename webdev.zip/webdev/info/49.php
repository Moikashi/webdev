
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>INDIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">49.</span>
            <span class="r-one">114.82</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Indium">In</a>

            <hr class="h-line">
            <span class="e-name">INDIUM</span>
            <span class="n-m">(Post-transition metals)</span>
            <div class="info">
                <span>Atomic mass: 114.82 u</span>
                <span>Melting point: 156.63°C (429.78 K)</span>
                <span>Boiling point: 2072°C (2345.15 K)</span>
                <span>Discovery date: 1863</span>
                <span>Discovered by: Ferdinand Reich</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">INDIUM</span>
                <span class="first">Indium is a chemical element with the symbol In and atomic number 49.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the term "indigo" for the indigo-blue line in the element's spark spectrum. It was discovered in 1863 by the German physicist Ferdinand Reich and the German metallurgist Hieronymus Theodor Richter, while examining zinc blende. They isolated indium in 1867. Indium was discovered by the German chemists Ferdinand Reich and Hieronymus Theodor Richter in 1863. Reich and Richter had been looking for traces of the element thallium in samples of zinc ores. A brilliant indigo line in the sample's spectrum revealed the existence of indium. Indium is about as abundant as silver but is much easier to recover since it typically occurs along with zinc, iron, lead and copper ores.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Indium is a soft, malleable metal with a brilliant lustre. The name indium originates from the indigo blue it shows in a spectroscope. Indium has a low melting point for metals and above its melting point it ignites burning with a violet flame.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
   
    
</body>
</html>