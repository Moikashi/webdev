
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>LEAD</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">82.</span>
            <span class="r-one">207.20</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Lead">Pb</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">LEAD</span>
            <span class="n-m">(Post-transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 207.20 u</span>
                <span>Melting point: 327.5°C (600.65 K)</span>
                <span>Boiling point: 1749°C (2022.15 K)</span>
                <span>Discovery date: 7000 BCE</span>
                <span>Discovered by: N/A</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">LEAD</span>
                <span class="first">Lead is a chemical element with the symbol Pb (from the Latin plumbum) and atomic number 82. It is a heavy metal that is denser than most common materials. Lead is soft and malleable, and also has a relatively low melting point.</span>
                <span class="history">HISTORY</span>
                <span class="second">Lead was one of the first metals known to man. The history of element 82 can be traced back to as early as 6,400 BC from the Neolithic settlement Çatalhöyük (situated in the central part of modern day Turkey).</span>
                <span class="facts">FACTS</span>
                <span class="third">Lead is a considered a basic metal or post-transition metal. It is a shiny blue-white metal when freshly cut, but oxidizes to a dull gray in air. </span>
            </div>
        </div>

   
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>