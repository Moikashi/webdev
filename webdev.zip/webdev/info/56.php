
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>BARIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">56.</span>
            <span class="r-one">137.33</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Barium">Ba</a>

            <hr class="h-line">
            <span class="e-name">BARIUM</span>
            <span class="n-m">(Alkaline earth metals)</span>
            <div class="info">
                <span>Atomic mass: 137.33 u</span>
                <span>Melting point: 727°C (1000.15 K)</span>
                <span>Boiling point: 1897°C (2170.15 K)</span>
                <span>Discovery date: 1808</span>
                <span>Discovered by: Humphry Davy, Carl Wilhelm Scheele</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">BARIUM</span>
                <span class="first">Barium is a chemical element with the symbol Ba and atomic number 56. It is the fifth element in group 2 and is a soft, silvery alkaline earth metal.</span>

                <span class="history">HISTORY</span>
                <span class="second">Barium was first isolated by Sir Humphry Davy, an English chemist, in 1808 through the electrolysis of molten baryta (BaO). Barium is never found free in nature since it reacts with oxygen in the air, forming barium oxide (BaO), and with water, forming barium hydroxide (Ba(OH)2) and hydrogen gas (H2). Barium is most commonly found as the mineral barite (BaSO4) and witherite (BaCO3) and is primarily produced through the electrolysis of barium chloride (BaCl2). From the Greek word barys, heavy. Baryta was distinguished from lime by Scheele in 1774; the element was discovered by Sir Humphrey Davy in 1808.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Barium is often used for spark-plug electrodes and in vacuum tubes as a drying and oxygen-removing agent. As well as fluorescent lamps: impure barium sulfide phosphorescence after exposure to light. Its compounds are used by oil and gas industries to make drilling mud.</span>
            </div>
        </div>

<style>
    .b-info .info{line-height: 50px;}

    </style>
   
    
</body>
</html>