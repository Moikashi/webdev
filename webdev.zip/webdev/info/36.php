
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>KRYPTON</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">36.</span>
            <span class="r-one">83.798 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Krypton">Kr</a>

            <hr class="h-line">
            <span class="e-name">KRYPTON</span>
            <span class="n-m">(Noble gases)</span>
            <div class="info">
                <span>Atomic mass: 83.798 u</span>
                <span>Melting point: -157.36°C (115.79 K)</span>
                <span>Boiling point: -153.41°C (119.74 K)</span>
                <span>Discovery date: 1898</span>
                <span>Discovered by: William Ramsay, Morris Travers</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">KRYPTON</span>
                <span class="first">Krypton is a chemical element with the symbol Kr and atomic number 36.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek kryptos for "concealed" or "hidden". It was discovered in liquefied atmospheric air by the Scottish chemist William Ramsay and the English chemist Morris William Travers in 1898. A wavelength in the atomic spectrum of 86Kr is a fundamental standard of length. Krypton was discovered on May 30, 1898 by Sir William Ramsay, a Scottish chemist, and Morris M. Travers, an English chemist, while studying liquefied air. Small amounts of liquid krypton remained behind after the more volatile components of liquid air had boiled away. The earth's atmosphere is about 0.0001% krypton.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Krypton is used commercially as a filling gas for energy-saving fluorescent lights. It is also used in some flash lamps used for high-speed photography. Unlike the lighter gases in its group, it is reactive enough to form some chemical compounds. For example, krypton will react with fluorine to form krypton fluoride.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>