
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>CAESIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">55.</span>
            <span class="r-one">132.91</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Caesium">Cs</a>

            <hr class="h-line">
            <span class="e-name">CAESIUM</span>
            <span class="n-m">(Alkali metals)</span>
            <div class="info">
                <span>Atomic mass: 132.91 u</span>
                <span>Melting point: 28.44°C (301.59 K)</span>
                <span>Boiling point: 670.85°C (944 K)</span>
                <span>Discovery date: 1860</span>
                <span>Discovered by: Gustav Kirchhoff, Robert Bunsen</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">CAESIUM</span>
                <span class="first">Caesium is a chemical element with the symbol Cs and atomic number 55. It is a soft, silvery-golden alkali metal with a melting point of 28.5 °C.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin caesius for "sky blue", which was the colour of the caesium line in the spectroscope. Caesium was discovered by the German chemist Robert Wilhelm Bunsen and the German physicist Gustav Robert Kirchhoff in 1860. It was first isolated by the German chemist Carl Setterberg in 1882. Cesium was discovered by Robert Wilhelm Bunsen and Gustav Robert Kirchhoff, German chemists, in 1860 through the spectroscopic analysis of Durkheim mineral water. They named cesium after the blue lines they observed in its spectrum. Today, cesium is primarily obtained from the mineral pollucite (CsAlSi2O6). Obtaining pure cesium is difficult since cesium ores are frequently contaminated with rubidium, an element that is chemically similar to cesium. To obtain pure cesium, cesium and rubidium ores are crushed and heated with sodium metal to 650°C, forming an alloy that can then be separated with a process known as fractional distillation. Metallic cesium is too reactive to easily handle and is usually sold in the form of cesium azide (CsN3). Cesium is recovered from cesium azide by heating it.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Cesium was first discovered by German scientists Robert Bunsen and Gustav Kirchhoff in 1860 during the spectroscopic analysis of mineral water from a nearby town. Cesium was the first element to be discovered using the spectroscope (Fig. 2), which was invented by Bunsen and Kirchhoff a year prior.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>