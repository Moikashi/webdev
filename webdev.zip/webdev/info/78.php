
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>PLATINUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/Home.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">78.</span>
            <span class="r-one">195.08</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Platinum">Pt</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">PLATINUM</span>
            <span class="n-m">(Transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 195.08 u</span>
                <span>Melting point: 1768.3°C (2041.45 K)</span>
                <span>Boiling point: 3825°C (4098.15 K)</span>
                <span>Discovery date: 1735</span>
                <span>Discovered by: Antonio de Ulloa</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">PLATINUM</span>
                <span class="first">Platinum is a chemical element with the symbol Pt and atomic number 78. It is a dense, malleable, ductile, highly unreactive, precious, silverish-white transition metal. Its name originates from Spanish platina, a diminutive of plata "silver".</span>
                <span class="history">HISTORY</span>
                <span class="second">In the early 1800s, Englishmen William Hyde Wollaston and Smithson Tennant discovered how to make platinum malleable , effectively opening the door to platinum's extensive commercial applications. Platinum was discovered in Russia in 1822, and shortly thereafter, it began to be fashioned into decorative chains.</span>
                <span class="facts">FACTS</span>
                <span class="third">Meteorites and our moon contain a higher percentage of platinum than can be found on the Earth.</span>
            </div>
        </div>

   
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>