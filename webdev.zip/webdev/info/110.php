
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>DARMSTADTIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">110.</span>
            <span class="r-one">281</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Darmstadtium">Ds</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">DARMSTADTIUM</span>
            <span class="n-m">(Unknown properties)</span>
            <div class="info">
                <span>Atomic mass: 281 u</span>
                <span>Melting point: Unknown</span>
                <span>Boiling point: Unknown</span>
                <span>Discovery date: 1994</span>
                <span>Discovered by: Victor Ninov, Sigurd Hofmann</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">DARMSTADTIUM</span>
                <span class="first">Darmstadtium is a chemical element with the symbol Ds and atomic number 110. It is an extremely radioactive synthetic element. The most stable known isotope, darmstadtium-281, has a half-life of approximately 12.7 seconds.</span>
                <span class="history">HISTORY</span>
                <span class="second">History and Uses: Darmstadtium was first produced by Peter Armbruster, Gottfried Münzenber and their team working at the Gesellschaft für Schwerionenforschung in Darmstadt, Germany on November 9th, 1994. They bombarded atoms of lead with ions of nickel with a device known as a linear accelerator.</span>
                <span class="facts">FACTS</span>
                <span class="third">Darmstadtium is a radioactive, synthetic element about which little is known.</span>
            </div>
        </div>

   <style>
    .b-info .info{line-height: 50px;}

    </style>
    
</body>
</html>