
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>THORIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">90.</span>
            <span class="r-one">232.04</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Thorium">Th</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">THORIUM</span>
            <span class="n-m">(Actinides)</span>
            <div class="info">
                <span>Atomic mass: 232.04 u</span>
                <span>Melting point: 1754.85°C (2028 K)</span>
                <span>Boiling point: 4786.85°C (5060 K)</span>
                <span>Discovery date: 1828</span>
                <span>Discovered by: Jöns Jacob Berzelius</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">THORIUM</span>
                <span class="first">Thorium is a weakly radioactive metallic chemical element with the symbol Th and atomic number 90. Thorium is silvery and tarnishes black when it is exposed to air, forming thorium dioxide; it is moderately soft and malleable and has a high melting point.</span>
                <span class="history">HISTORY</span>
                <span class="second">Thorium is a naturally-occurring, slightly radioactive metal discovered in 1828 by the Swedish chemist Jons Jakob Berzelius, who named it after Thor, the Norse god of thunder. It is found in small amounts in most rocks and soils, where it is about three times more abundant than uranium.</span>
                <span class="facts">FACTS</span>
                <span class="third">Thorium is used to make ceramics, welding rods, camera and telescope lenses, fire brick, heat resistant paint and metals used in the aerospace industry, as well as in nuclear reactions. </span>
            </div>
        </div>

   
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>