
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>EINSTEINIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">99.</span>
            <span class="r-one">252</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Einsteinium">Es</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">EINSTEINIUM</span>
            <span class="n-m">(Actinides)</span>
            <div class="info">
                <span>Atomic mass: 252 u</span>
                <span>Melting point: 860°C (1133.15 K)</span>
                <span class="bp">Boiling point: 1269 K ​(996 °C, ​1825 °F) (estimated)</span>
                <span>Discovery date: 1952</span>
                <span class="disco">Discovered by: Albert Ghiorso, Glenn T. Seaborg</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">EINSTEINIUM</span>
                <span class="first">Einsteinium is a synthetic element with the symbol Es and atomic number 99. Einsteinium is a member of the actinide series and it is the seventh transuranium element. It was named in honor of Albert Einstein.</span>
                <span class="history">HISTORY</span>
                <span class="second">Its discovery was not revealed for at least three years. It was suggested in the Physical Review in 1955 that the element be named after Einstein. It was found in the debris of the first hydrogen bomb, through the detonation of a thermonuclear device called “Ivy Mike” in the Pacific Ocean.</span>
                <span class="facts">FACTS</span>
                <span class="third">einsteinium (Es), synthetic chemical element of the actinoid series of the periodic table, atomic number 99. Einsteinium glows blue in the dark due to the great release of energy as it undergoes radioactive decay, according to Redfern.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>