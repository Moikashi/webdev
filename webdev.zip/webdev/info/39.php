
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>YTTRIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">39.</span>
            <span class="r-one">88.906</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Yttrium">Y</a>

            <hr class="h-line">
            <span class="e-name">YTTRIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 88.906 u</span>
                <span>Melting point: 1526°C (1799.15 K)</span>
                <span>Boiling point: 3337.85°C (3611 K)</span>
                <span>Discovery date: 1794</span>
                <span>Discovered by: Johan Gadolin</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">YTTRIUM</span>
                <span class="first">Yttrium is a chemical element with the symbol Y and atomic number 39.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Swedish village of Ytterby where the mineral gadolinite was found. In 1794, the Finnish chemist Johan Gadolin discovered yttrium in the mineral ytterbite, which was later renamed gadolinite for Gadolin. Gadolin originally called the element ytterbium after ytterbite. The name was subsequently shortened to yttrium, and later another element was given the name ytterbium. Yttrium was discovered by Johan Gadolin, a Finnish chemist, while analyzing the composition of the mineral gadolinite ((Ce, La, Nd, Y)2FeBe2Si2O10) in 1789. Gadolinite, which was named for Johan Gadolin, was discovered several years earlier in a quarry near the town of Ytterby, Sweden. Today, yttrium is primarily obtained through an ion exchange process from monazite sand ((Ce, La, Th, Nd, Y)PO4), a material rich in rare earth elements.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Yttrium is often used as an additive in alloys. It increases the strength of aluminium and magnesium alloys. It is also used in the making of microwave filters for radar and has been used as a catalyst in ethene polymerisation. Yttrium-aluminium garnet (YAG) is used in lasers that can cut through metals.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>