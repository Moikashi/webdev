
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>PALLADIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>  
    
        <div class="b-info">
            <span class="l-one">46.</span>
            <span class="r-one">106.42</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Palladium">Pd</a>

            <hr class="h-line">
            <span class="e-name">PALLADIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 106.42 u</span>
                <span>Melting point: 1554.9°C (1828.05 K)</span>
                <span>Boiling point: 2963°C (3236.15 K)</span>
                <span>Discovery date: 1803</span>
                <span>Discovered by: William Hyde Wollaston</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">PALLADIUM</span>
                <span class="first">Palladium is a chemical element with the symbol Pd and atomic number 46. It is a rare and lustrous silvery-white metal discovered in 1803 by the English.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the second largest asteroid of the solar system Pallas (named after the goddess of wisdom and arts—Pallas Athene). The element was discovered by the English chemist and physicist William Hyde Wollaston in 1803, one year after the discovery of Pallas by the German astronomer Wilhelm Olbers in 1802. The discovery was originally published anonymously by Wollaston to obtain priority, while not disclosing any details about his preparation. Palladium was discovered by William Hyde Wollaston, an English chemist, in 1803 while analyzing samples of platinum ore that were obtained from South America. Although it is a rare element, palladium tends to occur along with deposits of platinum, nickel, copper, silver and gold and is recovered as a byproduct of mining these other metals.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Palladium has the lowest melting point (2830.82 °F) and is the least dense of the PGMs. Deposits of palladium are rare, but are found in South Africa, Canada, and Russia. Much of the world's demand for palladium is met by recycling catalytic converters.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>