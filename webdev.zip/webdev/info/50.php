
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>TIN</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">50.</span>
            <span class="r-one">118.71</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Tin">Sn</a>

            <hr class="h-line">
            <span class="e-name">TIN</span>
            <span class="n-m">(Post-transition metals)</span>
            <div class="info">
                <span>Atomic mass: 118.71 u</span>
                <span>Melting point: 231.93°C (505.08 K)</span>
                <span>Boiling point: 2602°C (2875.15 K)</span>
                <span>Discovery date: N/A</span>
                <span>Discovered by: N/A</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">TIN</span>
                <span class="first">Tin is a chemical element with the symbol Sn and atomic number 50. Tin is a silvery-coloured metal.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Anglo-Saxon tin of unknown origin. The symbol Sn is derived from Latin stannum for alloys containing lead. The element was known in prehistoric times. Archaeological evidence suggests that people have been using tin for at least 5500 years. Tin is primarily obtained from the mineral cassiterite (SnO2) and is extracted by roasting cassiterite in a furnace with carbon. Tin makes up only about 0.001% of the earth's crust and is chiefly mined in Malaysia. Two allotropes of tin occur near room temperature. The first form of tin is called gray tin and is stable at temperatures below 13.2°C (55.76°F). There are few, if any, uses for gray tin. At temperatures above 13.2°C, gray tin slowly turns into tin's second form, white tin. White tin is the normal form of the metal and has many uses. Unfortunately, white tin will turn into gray tin if its temperature falls below 13.2°C. This change can be prevented if small amounts of antimony or bismuth are added to white tin.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Tin has many uses. It takes a high polish and is used to coat other metals to prevent corrosion, such as in tin cans, which are made of tin-coated steel. Alloys of tin are important, such as soft solder, pewter, bronze and phosphor bronze. A niobium-tin alloy is used for superconducting magnets.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>