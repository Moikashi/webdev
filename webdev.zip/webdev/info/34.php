
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>SELENIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">34.</span>
            <span class="r-one">78.960 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Selenium">Se</a>

            <hr class="h-line">
            <span class="e-name">SELENIUM</span>
            <span class="n-m">(Reactive nonmetals)</span>
            <div class="info">
                <span>Atomic mass: 74.922 u</span>
                <span>Melting point: 816.85°C (1090 K)</span>
                <span>Boiling point: 613°C (886.15 K)</span>
                <span>Discovery date: 1250</span>
                <span>Discovered by: Albertus Magnus</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">SELENIUM</span>
                <span class="first">Selenium is a chemical element with the symbol Se and atomic number 34.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek Selene, who was the Greek goddess of the Moon because the element is chemically found with tellurium (Tellus was the Roman goddess of the Earth). Selenium was discovered by the Swedish chemist Jöns Jacob Berzelius in 1817, while trying to isolate tellurium in an impure sample. Selenium was discovered by Jöns Jacob Berzelius, a Swedish chemist, in 1817 after analyzing an impurity that was contaminating the sulfuric acid (H2SO4) being produced at a particular factory in Sweden. Originally believing the material was tellurium, Berzelius eventually realized that it was actually a previously element.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Selenium is an essential component of various enzymes and proteins, called selenoproteins, that help to make DNA and protect against cell damage and infections; these proteins are also involved in reproduction and the metabolism of thyroid hormones.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>