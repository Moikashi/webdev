
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>ZIRCONIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">40.</span>
            <span class="r-one">91.224</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Zirconium">Zr</a>

            <hr class="h-line">
            <span class="e-name">ZIRCONIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 91.224 u</span>
                <span>Melting point: 1854.85°C (2128 K)</span>
                <span>Boiling point: 4408.85°C (4682 K)</span>
                <span>Discovery date: 1789</span>
                <span>Discovered by: Martin Heinrich Klaproth</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">ZIRCONIUM</span>
                <span class="first">Zirconium is a chemical element with the symbol Zr and atomic number 40.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Arabic zargun for "gold-like". It was discovered in zirconia by the German chemist Martin-Heinrich Klaproth in 1789. Zirconium was first isolated by Swedish chemist Jöns Jacob Berzelius in 1824 in an impure state, and finally by the chemists D. Lely, Jr. and L. Hamburger in a pure state in 1914. Zirconium was discovered by Martin Heinrich Klaproth, a German chemist, while analyzing the composition of the mineral jargon (ZrSiO4) in 1789. Zirconium was isolated by Jöns Jacob Berzelius, a Swedish chemist, in 1824 and finally prepared in a pure form in 1914. Obtaining pure zirconium is very difficult because it is chemically similar to hafnium, an element which is always found mixed with deposits of zirconium. Today, most zirconium is obtained from the minerals zircon (ZrSiO4) and baddeleyite (ZrO2) through a process known as the Kroll Process.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Zirconium is a shiny silver-grey metal. It is highly ductile and extremely resistant to corrosion and heat. Its symbol in the periodic table is Zr, and its atomic number is 40. It melts at 1855 degrees Celsius (°C) and boils at 4409 °C, and it is not corroded by acids, alkalis or seawater.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>