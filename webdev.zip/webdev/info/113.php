
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>NIHONIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">113.</span>
            <span class="r-one">286</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Nihonium">Nh</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">NIHONIUM</span>
            <span class="n-m">(Unknown properties)</span>
            <div class="info">
                <span>Atomic mass: 286 u</span>
                <span>Melting point: Unknown</span>
                <span>Boiling point: Unknown</span>
                <span>Discovery date: 2003</span>
                <span>Discovered by: Riken</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">NIHONIUM</span>
                <span class="first">Nihonium is a synthetic chemical element with the symbol Nh and atomic number 113. It is extremely radioactive; its most stable known isotope, nihonium-286, has a half-life of about 10 seconds. In the periodic table, nihonium is a transactinide element in the p-block. It is a member of period 7 and group 13 (boron group).</span>
                <span class="history">HISTORY</span>
                <span class="second">In January 2016 the discovery of element 113 was recognized by the International Union of Pure and Applied Chemistry (IUPAC) and the International Union of Pure and Applied Physics (IUPAP). The discoverers named it nihonium after the Japanese word for Japan. The name nihonium was approved by IUPAC in November 2016.</span>
                <span class="facts">FACTS</span>
                <span class="third">The element has six isotopes with known and confirmed half-lives, the longest-lived of which is nihonium-286 with a half-life of 19.6 seconds</span>
            </div>
        </div>

        <style>

            .e-info .h-info{
                position: absolute;
                top: 9%;
            }

    .b-info .info{line-height: 60px;}


        </style>

</body>
</html>