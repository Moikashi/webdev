
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>MOLYBDENUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">42.</span>
            <span class="r-one">95.950 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Molybdenum">Mo</a>

            <hr class="h-line">
            <span class="e-name">MOLYBDENUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 92.906 u</span>
                <span>Melting point: 2622.85°C (2896 K)</span>
                <span>Boiling point: 4638.85°C (4912 K)</span>
                <span>Discovery date: 1778</span>
                <span>Discovered by: Carl Wilhelm Scheele</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">MOLYBDENUM</span>
                <span class="first">Molybdenum is a chemical element with the symbol Mo and atomic number 42 which is located in period 5 and group 6.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek molybdos for "lead". The ancients used the term "lead" for any black mineral that leaves a mark on paper. Molybdenum was discovered by the Swedish pharmacist and chemist Carl Wilhelm Scheele in 1778. It was first isolated by the Swedish chemist Peter-Jacob Hjelm in 1781. Molybdenum was discovered by Carl Welhelm Scheele, a Swedish chemist, in 1778 in a mineral known as molybdenite (MoS2) which had been confused as a lead compound. Molybdenum was isolated by Peter Jacob Hjelm in 1781. Today, most molybdenum is obtained from molybdenite, wulfenite (PbMoO4) and powellite (CaMoO4). These ores typically occur in conjunction with ores of tin and tungsten. Molybdenum is also obtained as a byproduct of mining and processing tungsten and copper.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Molybdenum is a hard, silvery-white metallic element (Fig. 1) that is classified as a "transition metal." Transition metals are ductile, malleable and able to conduct electricity and heat. Molybdenum has one of the highest melting points of all pure elements, 2623°C (4753°F).</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
   
    
</body>
</html>