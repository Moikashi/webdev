
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>RHENIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">75.</span>
            <span class="r-one">186.21</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Rhenium">Re</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">RHENIUM</span>
            <span class="n-m">(Transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 186.21 u</span>
                <span>Melting point: 3181.85°C (3455 K)</span>
                <span>Boiling point: 5596.85°C (5870 K)</span>
                <span>Discovery date: 1925</span>
                <span class="disco">Discovered by: Walter Noddack, Ida Noddack, Otto Berg</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">RHENIUM</span>
                <span class="first">Rhenium is a chemical element with the symbol Re and atomic number 75. It is a silvery-gray, heavy, third-row transition metal in group 7 of the periodic table.</span>
                <span class="history">HISTORY</span>
                <span class="second">Rhenium was discovered in 1925 by Walter Noddack, Ida Noddack-Tacke, and Otto Berg in Germany in platinum ores, such as columbite and tung-state. J. G. F. Druce discovered it independently in manganese sulfate.</span>
                <span class="facts">FACTS</span>
                <span class="third">White silver-white metal, has the third highest melting point of any of the metals only exceeded by tungsten and carbon. It is the last stable, non-radioactive, naturally occurring element that has been discovered.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>