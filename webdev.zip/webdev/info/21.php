
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>SCANDIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">21.</span>
            <span class="r-one">44.956 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Scandium">Sc</a>
            <!--<p class="h">N</p>-->
            <hr class="h-line">
            <span class="e-name">SCANDIUM</span>
            <span class="n-m">(        )</span>
            <div class="info">
                <span>Atomic mass: 44.956 u</span>
                <span>Melting point: 1540.85°C (1814 K)</span>
                <span>Boiling point: 2835.85°C (3109 K)</span>
                <span>Discovery date: 1879</span>
                <span>Discovered by: Per Teodor Cleve, Lars Fredrik Nilson</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">SCANDIUM</span>
                <span class="first">Scandium is a chemical element with the symbol Sc and atomic number 21. It is a silvery-white metallic d-block element.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin scandia for Scandinavia, where the mineral was found. It was discovered by the Swedish chemist Lars-Fredrik Nilson in 1879 in an ytterbium sample. In the same year, the Swedish chemist Per Theodore Cleve proved that scandium was Mendeleev's predicted "eka-boron". Scandium was discovered by Lars Fredrik Nilson, a Swedish chemist, in 1879 while attempting to produce a sample of pure ytterbia from 10 kilograms of the mineral euxenite ((Y, Ca, Er, La, Ce, U, Th)(Nb, Ta, Ti)2O6). Scandium can be obtained from the minerals thortveitite ((Sc, Y)2Si2O7), bazzite (Be3(Sc, Al)2Si6O18) and wiikite, but is usually obtained as a byproduct of refining uranium.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Scandium is a silvery-white relatively light and soft metal at room temperature. When exposed to air, pure scandium develops a pink-yellow oxidation layer.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>