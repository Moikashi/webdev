
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>BISMUTH</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/Home.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">83.</span>
            <span class="r-one">208.98</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Bismuth">Bi</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">BISMUTH</span>
            <span class="n-m">(Post-transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 208.98 u</span>
                <span>Melting point: 271.44°C (544.59 K)</span>
                <span>Boiling point: 1564°C (1837.15 K)</span>
                <span>Discovery date: 1753</span>
                <span>Discovered by: Claude François Geoffroy</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">BISMUTH</span>
                <span class="first">Bismuth is a chemical element with the symbol Bi and atomic number 83. It is a post-transition metal and one of the pnictogens, with chemical properties resembling its lighter group 15 siblings arsenic and antimony.</span>
                <span class="history">HISTORY</span>
                <span class="second">Bismuth is an ancient element. It was one of the first ten metals to be discovered. In the beginning, scientists believed bismuth to be an alloy of tin and lead. Then, a French chemist named Claude Geoffroy finally distinguished bismuth as its own element in 1753.</span>
                <span class="facts">FACTS</span>
                <span class="third">Bismuth is a high-density, silvery, pink-tinged metal. Bismuth metal is brittle and so it is usually mixed with other metals to make it useful.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>