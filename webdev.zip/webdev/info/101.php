
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>MENDELEVIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">101.</span>
            <span class="r-one">258</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Mendelevium">Md</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">MENDELEVIUM</span>
            <span class="n-m">(Actinides)</span>
            <div class="info">
                <span>Atomic mass: 258 u</span>
                <span>Melting point: 826.85°C (1100 K)</span>
                <span>Boiling point: Unknown</span>
                <span>Discovery date: 1955</span>
                <span>Discovered by: Glenn T. Seaborg</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">MENDELEVIUM</span>
                <span class="first">Mendelevium is a synthetic element with the symbol Md (formerly Mv) and atomic number 101. A metallic radioactive transuranium element in the actinide series, it is the first element by atomic number that currently cannot be produced in macroscopic quantities by neutron bombardment of lighter elements.</span>
                <span class="history">HISTORY</span>
                <span class="second">Mendelevium was discovered by bombarding einsteinium with alpha particles in 1955, the method still used to produce it today. It was named after Dmitri Mendeleev, father of the periodic table of the chemical elements.</span>
                <span class="facts">FACTS</span>
                <span class="third">Mendelevium is named after the Russian chemist Dmitri Mendeleev. It is the first element that can't be produced in large quantities by neutron bombardment</span>
            </div>
        </div>

        <style>

            .e-info .h-info{
                position: absolute;
                top: 10%;
            }

    .b-info .info{line-height: 60px;}

        </style>
    
</body>
</html>