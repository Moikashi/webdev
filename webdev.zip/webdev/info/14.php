<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>SILICON</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>     

        <div class="b-info">
            <span class="l-one">14.</span>
            <span class="r-one">28.086</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Silicon">Si</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">SILICON</span>
            <span class="n-m">(       )</span>
            <div class="info">
                <span>Atomic mass:28.086 u</span>
                <span>Melting point:1410°C (1683.15 K)</span>
                <span>Boiling point:2355°C (2628.15 K)</span>
                <span>Discovery date:1824</span>
                <span>Discovered by:Jöns Jacob Berzelius, Antoine Lavoisier</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">SILICON</span>
                <span class="first">Silicon is a chemical element with the symbol Si and atomic number 14. It is a hard, brittle crystalline solid with a blue-grey metallic luster, and is a tetravalent metalloid and semiconductor. </span>
                <span class="history">HISTORY</span>
                <span class="second">Silicon was discovered by Jöns Jacob Berzelius, a Swedish chemist, in 1824 by heating chips of potassium in a silica container and then carefully washing away the residual by-products. Silicon is the seventh most abundant element in the universe and the second most abundant element in the earth's crust. Today, silicon is produced by heating sand (SiO2) with carbon to temperatures approaching 2200°C.</span>
                <span class="facts">FACTS</span>
                <span class="third">Silicon is used mostly for glass, ceramics and cement.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>