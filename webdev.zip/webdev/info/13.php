
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>ALUMINIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>     

        <div class="b-info">
            <span class="l-one">13.</span>
            <span class="r-one">26.982</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Aluminium">Al</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">ALUMINIUM</span>
            <span class="n-m">(       )</span>
            <div class="info">
                <span>Atomic mass:26.982 u</span>
                <span>Melting point:660.32°C (933.47 K)</span>
                <span>Boiling point:2470°C (2743.15 K)</span>
                <span>Discovery date:1825</span>
                <span>Discovered by:Hans Christian Ørsted</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">ALUMINIUM</span>
                <span class="first">Aluminium (aluminum in North American English) is a chemical element with the symbol Al and atomic number 13. Aluminium has a density lower than those of other common metals; about one-third that of steel.</span>
                <span class="history">HISTORY</span>
                <span class="second">The history of aluminium has been shaped by usage of alum. The first written record of alum, made by Greek historian Herodotus, dates back to the 5th century BCE. The ancients are known to have used alum as a dyeing mordant and for city defense. After the Crusades, alum, an indispensable good in the European fabric industry,was a subject of international commerce; it was imported to Europe from the eastern Mediterranean until the mid-15th century.</span>
                <span class="facts">FACTS</span>
                <span class="third">Aluminium doesn’t spark and it isn’t magnetic.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>