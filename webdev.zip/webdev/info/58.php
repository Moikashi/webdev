
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>CERIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">58.</span>
            <span class="r-one">140.12</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Cerium">Ce</a>

            <hr class="h-line">
            <span class="e-name">CERIUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 140.12 u</span>
                <span>Melting point: 795°C (1068.15 K)</span>
                <span>Boiling point: 3257°C (3530.15 K)</span>
                <span>Discovery date: 1803</span>
                <span>Discovered by: Jöns Jacob Berzelius, Martin Heinrich Klaproth, Carl Gustaf Mosander</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">CERIUM</span>
                <span class="first">Cerium is a chemical element with the symbol Ce and atomic number 58. Cerium is a soft, ductile, and silvery-white metal that tarnishes when exposed to air.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the planetoid Ceres, which was discovered by the Italian astronomer Giuseppe Piazzi in 1801 and named for Ceres, the Roman goddess of agriculture and harvest. Two years later, the element cerium was discovered by the German chemist Martin-Heinrich Klaproth, who called it ochroeite earth because of its yellow colour.Cerium was independently discovered at the same time by the Swedish chemist Jöns Jacob Berzelius and the Swedish mineralogist Wilhelm von Hisinger, who called it ceria. It was first isolated in 1875 by the American mineralogist and chemist William Frances Hillebrand and the American chemist Thomas H. Norton. Cerium was discovered by Jöns Jacob Berzelius and Wilhelm von Hisinger, Swedish chemists, and independently by Martin Heinrich Klaproth, a German chemist, in 1803. Cerium is the most abundant of the rare earth elements and makes up about 0.0046% of the earth's crust. Today, cerium is primarily obtained through an ion exchange process from monazite sand ((Ce, La, Th, Nd, Y)PO4), a material rich in rare earth elements.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">It can decompose slowly in cold water, and very rapidly in hot water. The metal can be attacked by alkaline solutions, dilute and concentrate acids. When scratched with a knife, the pure metal of cerium may ignite. Cerium is one of the most abundant of the rare-earth metals</span>
            </div>
        </div>


</body>
</html>