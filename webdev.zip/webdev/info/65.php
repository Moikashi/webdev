
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>TERBIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">65.</span>
            <span class="r-one">158.93</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Terbium">Tb</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">TERBIUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 158.93 u</span>
                <span>Melting point: 1355.85°C (1629 K)</span>
                <span>Boiling point: 3230°C (3503.15 K)</span>
                <span>Discovery date: 1843</span>
                <span>Discovered by: Carl Gustaf Mosander</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">TERBIUM</span>
                <span class="first">Terbium is a chemical element with the symbol Tb and atomic number 65. It is a silvery-white, rare earth metal that is malleable, and ductile.</span>
                <span class="history">HISTORY</span>
                <span class="second">History. Terbium was first isolated in 1843 by the Swedish chemist Carl Mosander at Stockholm. 
                    He had already investigated cerium oxide and separated a new element from it, lanthanum, 
                    and now he focussed his attention on yttrium, discovered in 1794, because he thought this 
                    too might harbour another element.</span>
                <span class="facts">FACTS</span>
                <span class="third">Terbium is a silvery rare-earth metal. It's soft, ductile and malleable. One of the lanthanide series, terbium is sandwiched between gadolinium (Gd) and dysprosium (Dy). </span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>