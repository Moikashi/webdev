
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>PRASEODYMIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">59.</span>
            <span class="r-one">140.91</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Praseodymium">Pr</a>

            <hr class="h-line">
            <span class="e-name">PRASEODYMIUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 140.91 u</span>
                <span>Melting point: 930.85°C (1204 K)</span>
                <span>Boiling point: 3520°C (3793.15 K)</span>
                <span>Discovery date: 1885</span>
                <span>Discovered by: Carl Auer von Welsbach</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">PRASEODYMIUM</span>
                <span class="first">Praseodymium is a chemical element with the symbol Pr and the atomic number 59. It is the third member of the lanthanide series and is considered to be one of the rare-earth metals. It is a soft, silvery, malleable and ductile metal, valued for its magnetic, electrical, chemical, and optical properties. It is too reactive to be found in native form, and pure praseodymium metal slowly develops a green oxide coating when exposed to air.</span>

                <span class="history">HISTORY</span>
                <span class="second">Praseodymium was first identified in 1885 by the Austrian chemist Carl Auer von Welsbach. At the time, von Welsbach was investigating a new kind of lighter flint, which emitted a more intense and consistent light compared to traditional flints. He noticed that the improved flints contained a new element, which he named praseodymium after the Greek words "prasios" and "didymos," meaning "green twin." This name was chosen because many of its salts have a greenish color. After its discovery, praseodymium attracted attention from scientists around the world who sought to understand its properties. Over time, it was found to be a soft, malleable, and ductile metal. It is highly reactive and readily oxidizes in air, forming a protective oxide layer on its surface. Praseodymium is also known for its distinct yellowish-green color when it is finely divided.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Praseodymium is a soft silver-colored metal that develops a green oxide coating in air. This coating peels or spalls off, exposing fresh metal to oxidation. To prevent degradation, pure praseodymium is typically stored under a protective atmosphere or in oil. Element 59 is highly malleable and ductile.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
   
    
</body>
</html>