
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>TITANIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>     
    
        <div class="b-info">
            <span class="l-one">22.</span>
            <span class="r-one">47.867 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Titanuim">Ti</a>

            <hr class="h-line">
            <span class="e-name">TITANIUM</span>
            <span class="n-m">(        )</span>
            <div class="info">
                <span>Atomic mass: 47.867 u</span>
                <span>Melting point: 1668°C (1941.15 K)</span>
                <span>Boiling point: 3286.85°C (3560 K)</span>
                <span>Discovery date: 1791</span>
                <span>Discovered by: William Gregor</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">TATINIUM</span>
                <span class="first">Titanium is a chemical element with the symbol Ti and atomic number 22.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin titans, who were the mythological "first sons of the earth". It was originally discovered by the English clergyman William Gregor in the mineral ilmenite (FeTiO3) in 1791. He called this mineral menachanite and the element menachin, for the Menachan parish where it was found. It was rediscovered in 1795 by the German chemist Martin Heinrich Klaproth, who called it titanium because it had no characteristic properties to use as a name. Titanium metal was first isolated by the Swedish chemists Sven Otto Pettersson and Lars Fredrik Nilson. Titanium was discovered in 1791 by the Reverend William Gregor, an English pastor. Pure titanium was first produced by Matthew A. Hunter, an American metallurgist, in 1910. Titanium is the ninth most abundant element in the earth's crust and is primarily found in the minerals rutile (TiO2), ilmenite (FeTiO3) and sphene (CaTiSiO5). Titanium makes up about 0.57% of the earth's crust.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">It is never found in its pure form naturally, it can only be found bonded to other elements. Titanium is corrosion resistant, even from water and chlorine. Titanium is found in almost every living thing.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>