<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>STRONTIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">38.</span>
            <span class="r-one">87.620</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Strontium">Sr</a>

            <hr class="h-line">
            <span class="e-name">STRONTIUM</span>
            <span class="n-m">(Alkaline earth metals)</span>
            <div class="info">
                <span>Atomic mass: 87.620 u</span>
                <span>Melting point: 777°C (1050.15 K)</span>
                <span>Boiling point: 1381.85°C (1655 K)</span>
                <span>Discovery date: 1790</span>
                <span>Discovered by: Adair Crawford, William Cruickshank, Humphry Davy</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">STRONTIUM</span>
                <span class="first">Strontium is the chemical element with the symbol Sr and atomic number 38.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from Strontian, a town in Scotland. The mineral strontianite is found in mines in Strontian. The element was discovered in 1792 by the Scottish chemist and physician Thomas Charles Hope, who observed the brilliant red flame colour of strontium. It was first isolated by the English chemist Humphry Davy in 1808.Strontium was discovered by Adair Crawford, an Irish chemist, in 1790 while studying the mineral witherite (BaCO3). When he mixed witherite with hydrochloric acid (HCl) he did not get the results he expected. He assumed that his sample of witherite was contaminated with an mineral, a mineral he named strontianite (SrCO3). Strontium was first isolated by Sir Humphry Davy, an English chemist, in 1808 through the electrolysis of a mixture of strontium chloride (SrCl2) and mercuric oxide (HgO).</span>
                
                <span class="facts">FACTS</span>
                <span class="third">A soft, silvery metal that burns in air and reacts with water. Strontium is best known for the brilliant reds its salts give to fireworks and flares. It is also used in producing ferrite magnets and refining zinc. Modern 'glow-in-the-dark' paints and plastics contain strontium aluminate.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>