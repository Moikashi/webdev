
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>EUROPIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">63.</span>
            <span class="r-one">151.96</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Europium">Eu</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">EUROPIUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 151.96 u</span>
                <span>Melting point: 826°C (1099.15 K)</span>
                <span>Boiling point: 1529°C (1802.15 K)</span>
                <span>Discovery date: 1901</span>
                <span class="disco">Discovered by: Paul-Émile Lecoq de Boisbaudran, Eugène-Anatole Demarçay</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">EUROPIUM</span>
                <span class="first">Europium is a chemical element with the symbol Eu and atomic number 63. Europium is a silvery-white metal of the lanthanide series that reacts readily with air to form a dark oxide coating.</span>
                <span class="history">HISTORY</span>
                <span class="second">The name derives from the continent of Europe. 
                    It was separated from the mineral samaria in magnesium- samarium nitrate by the 
                    French chemist Eugène-Anatole Demarçay in 1896. It was also first isolated by Demarçay in 1901. 
                    Europium was discovered by Eugène-Antole Demarçay, a French chemist, in 1896.</span>
                <span class="facts">FACTS</span>
                <span class="third">Europium is a soft, ductile, silvery-white metal that instantly oxidizes in air. </span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>