
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>CALCIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    

        <div class="b-info">
            <span class="l-one">20.</span>
            <span class="r-one">40.078</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Calcium">Ca</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">CALCIUM</span>
            <span class="n-m">(       )</span>
            <div class="info">
                <span>Atomic mass:40.078 u</span>
                <span>Melting point:842°C (1115.15 K)</span>
                <span>Boiling point:1483.85°C (1757 K)</span>
                <span>Discovery date:1808</span>
                <span>Discovered by:Humphry Davy</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">CALCIUM</span>
                <span class="first">Calcium is a chemical element with the symbol Ca and atomic number 20.</span>
                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin calx for "lime" (CaO) or "limestone" (CaCO3) in which it was found. It was first isolated by British chemist Humphry Davy in 1808 with help from the Swedish chemist Jöns Jacob Berzelius and the Swedish court physician M. M. af Pontin. Although calcium is the fifth most abundant element in the earth's crust, it is never found free in nature since it easily forms compounds by reacting with oxygen and water. Metallic calcium was first isolated by Sir Humphry Davy in 1808 through the electrolysis of a mixture of lime (CaO) and mercuric oxide (HgO). Today, metallic calcium is obtained by displacing calcium atoms in lime with atoms of aluminum in hot, low-pressure containers. About 4.2% of the earth's crust is composed of calcium.</span>
                <span class="facts">FACTS</span>
                <span class="third">Calcium is the most abundant mineral in the body. Almost all calcium in the body is stored in bones and teeth, giving them structure and hardness. Your body needs calcium for muscles to move and for nerves to carry messages between your brain and every part of your body.
                </span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>