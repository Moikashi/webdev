
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>ASTATINE</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>     
    
        <div class="b-info">
            <span class="l-one">85.</span>
            <span class="r-one">210</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Astatine">At</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">ASTATINE</span>
            <span class="n-m">(Post-transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 210 u</span>
                <span>Melting point: 301.85°C (575 K)</span>
                <span>Boiling point: 336.85°C (610 K)</span>
                <span>Discovery date: 1940</span>
                <span>Discovered by: Emilio Segrè</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">ASTATINE</span>
                <span class="first">Astatine is a chemical element with the symbol At and atomic number 85. It is the rarest naturally occurring element in the Earth's crust, occurring only as the decay product of various heavier elements. All of astatine's isotopes are short-lived; the most stable is astatine-210, with a half-life of 8.1 hours.</span>
                <span class="history">HISTORY</span>
                <span class="second">Astatine, which has no stable isotopes, was first synthetically produced (1940) at the University of California by American physicists Dale R. Corson, Kenneth R. MacKenzie, and Emilio Segrè, who bombarded bismuth with accelerated alpha particles (helium nuclei) to yield astatine-211 and neutrons.</span>
                <span class="facts">FACTS</span>
                <span class="third">Astatine is the heaviest known halogen (Group 17 of the periodic table).</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>