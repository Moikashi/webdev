
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>XENON</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">54.</span>
            <span class="r-one">131.29</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Xenon">Xe</a>

            <hr class="h-line">
            <span class="e-name">XENON</span>
            <span class="n-m">(Noble gases)</span>
            <div class="info">
                <span>Atomic mass: 131.29 u</span>
                <span>Melting point: -111.75°C (161.4 K)</span>
                <span>Boiling point: -108.12°C (165.03 K)</span>
                <span>Discovery date: 1898</span>
                <span>Discovered by: Morris Travers, William Ramsay</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">XENON</span>
                <span class="first">Xenon is a chemical element with the symbol Xe and atomic number 54. It is a dense, colorless, odorless noble gas found in Earth's atmosphere.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek xenos for "the stranger". It was discovered by the Scottish chemist William Ramsay and the English chemist Morris William Travers in 1898 in a liquefied air sample. Xenon was discovered by Sir William Ramsay, a Scottish chemist, and Morris M. Travers, an English chemist, on July 12, 1898, shortly after their discovery of the elements krypton and neon. Like krypton and neon, xenon was discovered through the study of liquefied air. The earth's atmosphere is about 0.0000087% xenon. From the Greek word xenon, stranger. Discovered in 1898 by Ramsay and Travers in residue left after evaporating liquid air. Xenon is a member of the so-called noble or "inert" gases. It is present in the atmosphere to the extent of about one part in twenty million. Xenon is present in the Martian atmosphere to the extent of 0.08 ppm. the element is found in the gases evolved from certain mineral springs, and is commercially obtained by extraction from liquid air.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Xenon was the first noble gas found to form chemical compounds. Heavy and extremely rare, this chemical element is colorless, odorless, and tasteless. It occurs in gases evolved from mineral springs on Earth and also in the Martian atmosphere.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
   
    
</body>
</html>