
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>HOLMIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">67.</span>
            <span class="r-one">164.93</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Holmium">Ho</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">HOLMIUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 164.93 u</span>
                <span>Melting point: 1474°C (1747.15 K)</span>
                <span>Boiling point: 2694.85°C (2968 K)</span>
                <span>Discovery date: 1878</span>
                <span class="disco">Discovered by: Per Teodor Cleve, Marc Delafontaine, Jacques-Louis Soret</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">HOLMIUM</span>
                <span class="first">Holmium is a chemical element with the symbol Ho and atomic number 67. It is a rare-earth element and the eleventh member of the lanthanide series.</span>
                <span class="history">HISTORY</span>
                <span class="second">Holmium was discovered at Geneva in 1878 by Marc Delafontaine and Louis Soret, 
                    and independently by Per Teodor Cleve at Uppsala, Sweden. Both teams were investigating yttrium, 
                    which was contaminated with traces of other rare earths (aka lanthanoids) and had already yielded 
                    erbium which was later to yield ytterbium.</span>
                <span class="facts">FACTS</span>
                <span class="third">Holmium is a rare earth element. Holmium is a bright, soft, silvery-white, rare earth metal that is both ductile and malleable. </span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>