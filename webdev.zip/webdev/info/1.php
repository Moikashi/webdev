
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>HYDROGEN</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
    <div class="b-info">
        <span class="l-one">1.</span>
        <span class="r-one">1.0078</span>
        <a class="h" href="https://en.wikipedia.org/wiki/Hydrogen">H</a>
        <!--<p class="h">H</p>-->
        <hr class="h-line">
        <span class="e-name">HYDROGEN</span>
        <span class="n-m">(Reactive nonmetals)</span>
        <div class="info">
            <span>Atomic mass: 1.0078 u</span>
            <span>Melting point: -259.16°C (13.99 K)</span>
            <span>Boiling point: -252.87°C (20.28 K)</span>
            <span>Discovery date: 1766</span>
            <span>Discovered by: Henry Cavendish</span>
        </div>
    </div>

    <div class="e-info">
        <div class="h-info">
            <span class="first-info">HYDROGEN</span>
            <span class="first">Hydrogen is the lightest element. At standard conditions hydrogen is a gas of diatomic molecules having the formula H2.</span>
            <span class="history">HISTORY</span>
            <span class="second">Hydrogen was discovered by the English physicist Henry Cavendish in 1766. 
                Scientists had been producing hydrogen for years before it was recognized as an element. 
                Written records indicate that Robert Boyle produced hydrogen gas as early as 1671 while experimenting with iron and acids</span>
            <span class="facts">FACTS</span>
            <span class="third">Hydrogen is colorless and odorless.</span>
        </div>
    </div>

    <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>