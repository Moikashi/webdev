<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>LANTHANUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">57.</span>
            <span class="r-one">138.91</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Lanthanum">La</a>

            <hr class="h-line">
            <span class="e-name">LANTHANUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 138.91 u</span>
                <span>Melting point: 920°C (1193.15 K)</span>
                <span>Boiling point: 3463.85°C (3737 K)</span>
                <span>Discovery date: 1839</span>
                <span>Discovered by: Carl Gustaf Mosander</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">LANTHANUM</span>
                <span class="first">Lanthanum is a chemical element with the symbol La and atomic number 57. It is a soft, ductile, silvery-white metal that tarnishes slowly when exposed to air.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek lanthanein for "to be hidden" or "to escape notice" because it hid in cerium ore and was difficult to separate from that rare earth mineral. Lanthanum was discovered by the Swedish surgeon and chemist Carl-Gustav Mosander in 1839. In 1842, Mosander separated his lanthanium sample into two oxides; for one of these he retained the name lanthanum and for the other he gave the name didymium (or twin).Lanthanum was discovered by Carl Gustaf Mosander, a Swedish chemist, in 1839. Mosander was searching for impurities he believed existed within samples of cerium. He treated cerium nitrate (Ce(NO3)3) with dilute nitric acid (HNO3) and found a new substance he named lanthana (La2O3). Roughly 0.0018% of the earth's crust is composed of lanthanum. Today, lanthanum is primarily obtained through an ion exchange process from monazite sand ((Ce, La, Th, Nd, Y)PO4), a material rich in rare earth elements that can contain as much as 25% lanthanum.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Lanthanum is silvery white, malleable, ductile, and soft enough to be cut with a knife. It is one of the most reactive of the rare-earth metals. It oxidizes rapidly when exposed to air. Cold water attacks lanthanum slowly, while hot water attacks it much more rapidly.</span>
            </div>
        </div>

<style>
    .b-info .info{line-height: 60px;}

    </style>
   
    
</body>
</html>