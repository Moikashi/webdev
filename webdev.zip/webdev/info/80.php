
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>MERCURY</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">80.</span>
            <span class="r-one">200.59</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Mercury_(element)">Hg</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">MERCURY</span>
            <span class="n-m">(Transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 200.59 u</span>
                <span>Melting point: -38.83°C (234.32 K)</span>
                <span>Boiling point: 356.73°C (629.88 K)</span>
                <span>Discovery date: 1500 BC</span>
                <span>Discovered by: N/A</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">MERCURY</span>
                <span class="first">Mercury is a chemical element with the symbol Hg and atomic number 80. It is also known as quicksilver and was formerly named hydrargyrum (/haɪˈdrɑːrdʒərəm/ hy-DRAR-jər-əm) from the Greek words hydor (water) and argyros (silver).</span>
                <span class="history">HISTORY</span>
                <span class="second">Mercury was among the first metals known, and its compounds have been used throughout history. Archaeologists found mercury in an Egyptian tomb dating from 1500 BC. The Egyptians and the Chinese may have been using cinnabar as a red pigment for centuries before the birth of Christ.</span>
                <span class="facts">FACTS</span>
                <span class="third">Mercury is the only metal on earth that is liquid at room temperature.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>