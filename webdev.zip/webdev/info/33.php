
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>ARSENIC</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">33.</span>
            <span class="r-one">74.922</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Arsenic">As</a>

            <hr class="h-line">
            <span class="e-name">ARSENIC</span>
            <span class="n-m">(Metalloids)</span>
            <div class="info">
                <span>Atomic mass: 74.922 u</span>
                <span>Melting point: 816.85°C (1090 K)</span>
                <span>Boiling point: 613°C (886.15 K)</span>
                <span>Discovery date: 1250</span>
                <span>Discovered by: Albertus Magnus</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">ARSENIC</span>
                <span class="first">Arsenic is a chemical element with the symbol As and atomic number 33.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin arsenicium and the Greek arsenikos for "masculine" or "male" because the ancients thought that metals were different sexes. Arsenic was known in prehistoric times for its poisonous sulfides. The German scientist and philosopher, Albert von Bollstadt (Albert the Great or Albertus Magnus) is thought to have obtained the metal around 1250. Although arsenic compounds were mined by the early Chinese, Greek and Egyptian civilizations, it is believed that arsenic itself was first identified by Albertus Magnus, a German alchemist, in 1250. Arsenic occurs free in nature, but is most often found in the minerals arsenopyrite (FeAsS), realgar (AsS) and orpiment (As2S3). Today, most commercial arsenic is obtained by heating arsenopyrite.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Chronic (long-term) exposure may lead to a variety of symptoms including skin pigmentation, numbness, cardiovascular disease, diabetes, and vascular disease. Arsenic is also known to cause a variety of cancers including skin cancer (non-melanoma type), kidney, bladder, lung, prostate and liver cancer.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>