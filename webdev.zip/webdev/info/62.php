
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>SAMARIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">62.</span>
            <span class="r-one">150.36</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Samarium">Sm</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">SAMARIUM</span>
            <span class="n-m">(Lanthanides)</span>
            <div class="info">
                <span>Atomic mass: 150.36 u</span>
                <span>Melting point: 1072°C (1345.15 K)</span>
                <span>Boiling point: 1793.85°C (2067 K)</span>
                <span>Discovery date: 1879</span>
                <span class="disco">Discovered by:Paul-Émile Lecoq de Boisbaudran</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">SAMARIUM</span>
                <span class="first">Samarium is a chemical element with symbol Sm and atomic number 62. 
                    It is a moderately hard silvery metal that slowly oxidizes in air.</span>
                <span class="history">HISTORY</span>
                <span class="second">Samarium is a rare earth element that - indirectly - has the distinction 
                    of being the first naturally occurring chemical element to be named after a living person. 
                    Samarium was isolated from the mineral Samarskite which was discovered near the small town 
                    of Miass in the southern Ural mountains in 1847.</span>
                <span class="facts">FACTS</span>
                <span class="third">Samarium is a yellowish silver-colored metal. It is the hardest and the most brittle of the rare earth elements.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>