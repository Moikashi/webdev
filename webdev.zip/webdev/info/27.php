
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>COBALT</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">27.</span>
            <span class="r-one">58.933</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Cobalt">Co</a>

            <hr class="h-line">
            <span class="e-name">COBALT</span>
            <span class="n-m">(Transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 58.933 u</span>
                <span>Melting point: 1495°C (1768.15 K)</span>
                <span>Boiling point: 2869.85°C (3143 K)</span>
                <span>Discovery date: 1735</span>
                <span>Discovered by: Georg Brandt</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">COBALT</span>
                <span class="first">Cobalt is a chemical element with the symbol Co and atomic number 27.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the German Kobold for "evil spirits" or "goblins", who were superstitiously thought to cause trouble for miners because the mineral contained arsenic that injured their health and the metallic ores did not yield metals when treated with the normal methods. Cobalt was discovered in 1735 by the Swedish chemist Georg Brandt. Cobalt was discovered by Georg Brandt, a Swedish chemist, in 1739. Brandt was attempting to prove that the ability of certain minerals to color glass blue was due to an element and not to bismuth, as was commonly believed at the time.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Cobalt forms part of the structure of vitamin B12. Vitamin B12 has several important functions including making red blood cells and releasing energy from the food you eat.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>  