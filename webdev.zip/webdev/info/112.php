
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>COPERNICIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>  
    
        <div class="b-info">
            <span class="l-one">112.</span>
            <span class="r-one">285</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Copernicium">Cn</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">COPERNICIUM</span>
            <span class="n-m">(Unknown properties)</span>
            <div class="info">
                <span>Atomic mass: 285 u</span>
                <span>Melting point: Unknown</span>
                <span>Boiling point: Unknown</span>
                <span>Discovery date: 1996</span>
                <span>Discovered by: Sigurd Hofmann, Victor Ninov</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">COPERNICIUM</span>
                <span class="first">Copernicium is a synthetic chemical element with the symbol Cn and atomic number 112. Its known isotopes are extremely radioactive, and have only been created in a laboratory. The most stable known isotope, copernicium-285, has a half-life of approximately 30 seconds.</span>
                <span class="history">HISTORY</span>
                <span class="second">Copernicium was first created on February 9, 1996, at the Gesellschaft für Schwerionenforschung (GSI) in Darmstadt, Germany, by Sigurd Hofmann, Victor Ninov et al. This element was created by firing accelerated zinc-70 nuclei at a target made of lead-208 nuclei in a heavy ion accelerator.</span>
                <span class="facts">FACTS</span>
                <span class="third">A highly radioactive metal, of which only a few atoms have ever been made. </span>
            </div>
        </div>

   
    <style>
    .b-info .info{line-height: 50px;}

    </style>
</body>
</html>