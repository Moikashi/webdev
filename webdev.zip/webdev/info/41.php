
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>NOIBIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">41.</span>
            <span class="r-one">92.906 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Niobium">Nb</a>

            <hr class="h-line">
            <span class="e-name">NOIBIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 92.906 u</span>
                <span>Melting point: 2468.85°C (2742 K)</span>
                <span>Boiling point: 4927°C (5200.15 K)</span>
                <span>Discovery date: 1801</span>
                <span>Discovered by: Charles Hatchett</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">NOIBIUM</span>
                <span class="first">Zirconium is a chemical element with the symbol Zr and atomic number 40.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek mythological character Niobe, who was the daughter of Tantalus, because the elements niobium and tantalum were originally thought to be identical. Niobium was discovered in a black mineral from America called columbite by the British chemist and manufacturer Charles Hatchett in 1801 and he called the element columbium. In 1809, the English chemist William Hyde Wollaston claimed that columbium and tantalum were identical. Forty years later, the German chemist and pharmacist, Heinrich Rose, determined that they were two different elements in 1846 and gave the name niobium because it was so difficult to distinguish it from tantalum. The name columbium continued to be used in America and niobium in Europe until IUPAC adopted the name niobium in 1949. Niobium was first isolated by the chemist C. W. Blomstrand in 1846.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Niobium was first discovered (1801) in an ore sample from Connecticut by the English chemist Charles Hatchett, who called the element columbium in honour of the country of its origin, Columbia being a synonym for the United States.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>