
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>IODINE</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">53.</span>
            <span class="r-one">126.90</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Iodine">I</a>

            <hr class="h-line">
            <span class="e-name">IODINE</span>
            <span class="n-m">(Reactive nonmetals)</span>
            <div class="info">
                <span>Atomic mass: 126.90 u</span>
                <span>Melting point: 113.7°C (386.85 K)</span>
                <span>Boiling point: 184.3°C (457.45 K)</span>
                <span>Discovery date: 1811</span>
                <span>Discovered by: Bernard Courtois</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">IODINE</span>
                <span class="first">Iodine is a chemical element with the symbol I and atomic number 53. The heaviest of the stable halogens, it exists as a semi-lustrous.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Greek iodes for "violet" because of its violet vapours. Iodine was discovered in seaweed by the French chemist Bernard Courtois in 1811, and named by the French chemist Louis-Joseph Gay-Lussac, when he proved it was an element in 1814.Iodine was discovered by the French chemist Barnard Courtois in 1811. Courtois was extracting sodium and potassium compounds from seaweed ash. Once these compounds were removed, he added sulfuric acid (H2SO4) to further process the ash. He accidentally added too much acid and a violet colored cloud erupted from the mass. The gas condensed on metal objects in the room, creating solid iodine. Today, iodine is chiefly obtained from deposits of sodium iodate (NaIO3) and sodium periodate (NaIO4) in Chile and Bolivia. Trace amounts of iodine are required by the human body.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Iodine is a mineral found in some foods. The body needs iodine to make thyroid hormones. These hormones control the body's metabolism and many other important functions. The body also needs thyroid hormones for proper bone and brain development during pregnancy and infancy.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>