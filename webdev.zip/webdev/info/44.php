
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>RUTHENIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">44.</span>
            <span class="r-one">101.07</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Ruthenium">Ru</a>

            <hr class="h-line">
            <span class="e-name">RUTHENIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 101.07 u</span>
                <span>Melting point: 2334°C (2607.15 K</span>
                <span>Boiling point: 4150°C (4423.15 K)</span>
                <span>Discovery date: 1844</span>
                <span>Discovered by: Karl Ernst Claus</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">RUTHENIUM</span>
                <span class="first">Ruthenium is a chemical element with the symbol Ru and atomic number 44. It is a rare transition metal belonging to the platinum group of the periodic table.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the Latin ruthenia for the old name of Russia. It was discovered in a crude platinum ore by the Russian chemist Gottfried Wilhelm Osann in 1828. Osann thought that he had found three new metals in the sample, pluranium, ruthenium, and polinium. In 1844, Russian chemist Karl Karlovich Klaus was able to show that Osann's mistake was due to the impurity of the sample, and Klaus was able to isolate the ruthenium metal.Ruthenium was discovered by Karl Karlovich Klaus, a Russian chemist, in 1844 while analyzing the residue of a sample of platinum ore obtained from the Ural mountains. Apparently, Jedrzej Sniadecki, a Polish chemist, had produced ruthenium in 1807 but he withdrew his claim of discovery after other scientists failed to replicate his results.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Ruthenium is one of the most effective hardeners for platinum and palladium, and is alloyed with these metals to make electrical contacts for severe wear resistance. It is used in some jewellery as an alloy with platinum. Ruthenium has no known biological role. Ruthenium(IV) oxide is highly toxic.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>