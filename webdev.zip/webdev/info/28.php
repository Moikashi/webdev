
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>NICKEL</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>    
    
        <div class="b-info">
            <span class="l-one">28.</span>
            <span class="r-one">58.693</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Nickel">Ni</a>

            <hr class="h-line">
            <span class="e-name">NICKEL</span>
            <span class="n-m">(Transition Metals)</span>
            <div class="info">
                <span>Atomic mass: 58.693 u</span>
                <span>Melting point: 1455°C (1728.15 K)</span>
                <span>Boiling point: 2730°C (3003.15 K)</span>
                <span>Discovery date: 1751</span>
                <span>Discovered by: Axel Fredrik Cronstedt</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">NICKEL</span>
                <span class="first">Nickel is a chemical element with symbol Ni and atomic number 28. It is a silvery-white lustrous metal with a slight golden tinge.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from the German Nickel for "deceptive little spirit" because miners called mineral niccolite (NiAs) by the name Kupfernickel (false copper) because it resembled copper ores in appearance, but no copper was found in the ore. It was discovered by the Swedish metallurgist Axel-Frederik Cronstedt in 1751. Nickel was discovered by the Swedish chemist Axel Fredrik Cronstedt in the mineral niccolite (NiAs) in 1751.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Nickel Institute says that nickel is highly ductile, corrosion and oxidation resistant and 100 percent recyclable. These characteristics make it essential for building infrastructure, chemical production, communications, energy supply, environmental protection and food preparation.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>  