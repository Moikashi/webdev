
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>NITROGEN</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">7.</span>
            <span class="r-one">14.007</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Nitrogen">N</a>
            <!--<p class="h">N</p>-->
            <hr class="h-line">
            <span class="e-name">NITROGEN</span>
            <span class="n-m">(Reactive nonmetals)</span>
            <div class="info">
                <span>Atomic mass: 14.007 u</span>
                <span>Melting point: -210.01°C (63.14 K)</span>
                <span>Boiling point: -195.79°C (77.36 K)</span>
                <span>Discovery date: 1772</span>
                <span>Discovered by: Daniel Rutherford</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">CARBON</span>
                <span class="first">Nitrogen is the chemical element with the symbol N and atomic number 7. Nitrogen is a nonmetal and the lightest member of group 15 of the periodic table, often called the pnictogens.</span>

                <span class="history">HISTORY</span>
                <span class="second">Nitrogen compounds have a very long history, ammonium chloride having been known to Herodotus. They were well-known by the Middle Ages. Alchemists knew nitric acid as aqua fortis (strong water), as well as other nitrogen compounds such as ammonium salts and nitrate salts. The mixture of nitric and hydrochloric acids was known as aqua regia (royal water), celebrated for its ability to dissolve gold, the king of metals.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">N has no odor, is tasteless, and colorless.</span>
            </div>
        </div>
        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>