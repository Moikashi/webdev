
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>RUTHERFORDIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">104.</span>
            <span class="r-one">267</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Rutherfordium">Rf</a>
            <!--<p class="h">H</p>-->
            <hr class="h-line">
            <span class="e-name">RUTHERFORDIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 267 u</span>
                <span>Melting point: 2100°C (2373.15 K)</span>
                <span>Boiling point: 5800 K ​(5500 °C, ​9900 °F)</span>
                <span>Discovery date: 1964</span>
                <span class="disco">Discovered by: Joint Institute for Nuclear Research, Albert Ghiorso</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">RUTHERFORDIUM</span>
                <span class="first">Rutherfordium is a chemical element with the symbol Rf and atomic number 104, named after physicist Ernest Rutherford. As a synthetic element, it is not found in nature and can only be made in a particle accelerator. It is radioactive; the most stable known isotope, 267Rf, has a half-life of about 48 minutes.</span>
                <span class="history">HISTORY</span>
                <span class="second">	Georgy Flerov and colleagues and at Dubna, near Moscow, Russia, and independently by Albert Ghiorso and colleagues at Berkeley, California, USA</span>
                <span class="facts">FACTS</span>
                <span class="third">The name Rutherfordium was decided upon after a long debate between US and Soviet research groups – both of whom claimed to have discovered the element first.</span>
            </div>
        </div>

        <style>
            
            .disco{ 
                line-height: 30px;
            
            }

    .b-info .info{line-height: 60px;}

        </style>
    
</body>
</html>