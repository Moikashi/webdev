
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>FLOURINE</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">9.</span>
            <span class="r-one">18.998 u</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Fluorine">F</a>
            <!--<p class="h">N</p>-->
            <hr class="h-line">
            <span class="e-name">FLOURINE</span>
            <span class="n-m">(Reactive nonmetals)</span>
            <div class="info">
                <span>Atomic mass: 18.998 u</span>
                <span>Melting point: -219.62°C (53.53 K)</span>
                <span>Boiling point: -188.11°C (85.04 K)</span>
                <span>Discovery date: 1886</span>
                <span>Discovered by: Henri Moissan</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">FLOURINE</span>
                <span class="first">Fluorine is a chemical element with the symbol F and atomic number 9. It is the lightest halogen and exists at standard conditions as a highly toxic, pale yellow diatomic gas. As the most electronegative reactive element, it is extremely reactive, as it reacts with all other elements except for the light inert gases.</span>

                <span class="history">HISTORY</span>
                <span class="second">In 1529, Georgius Agricola described fluorite as an additive used to lower the melting point of metals during smelting.He penned the Latin word fluorēs (fluor, fLow) for fluorite rocks. The name later evolved into fluorspar (still commonly used) and then fluorite. The composition of fluorite was later determined to be calcium difluoride. Hydrofluoric acid was used in glass etching from 1720 onward.[note 6] Andreas Sigismund Marggraf first characterized it in 1764 when he heated fluorite with sulfuric acid, and the resulting solution corroded its glass container.Swedish chemist Carl Wilhelm Scheele repeated the experiment in 1771, and named the acidic product fluss-spats-syran (fluorspar acid)</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Fluorine is the most reactive and the most electronegative of all the elements</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>