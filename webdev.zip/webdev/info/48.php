
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>CADMIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">48.</span>
            <span class="r-one">112.41</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Cadmium">Cd</a>

            <hr class="h-line">
            <span class="e-name">CADMIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 112.41 u</span>
                <span>Melting point: 321.11°C (594.26 K)</span>
                <span>Boiling point: 766.85°C (1040 K)</span>
                <span>Discovery date: 1817</span>
                <span>Discovered by: Karl Samuel Leberecht Hermann, Friedrich Stromeyer</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">CADMIUM</span>
                <span class="first">Cadmium is a chemical element with the symbol Cd and atomic number 48. This soft, silvery-white metal is chemically similar to the two other stable metals.</span>

                <span class="history">HISTORY</span>
                <span class="second">The name derives from Greek kadmeia for "calamine" (zinc carbonate), with which it was found as an impurity in nature. It may have been found in furnace flue dust in Thebes, a city in the Boeottia region of central Greece. The mythological king of Phoenicia, Cadmus, founded Thebes and would be a source for the name of the ore. The element was discovered and first isolated by German physician Friedrich Stromeyer in 1817.Cadmium was discovered by Friedrich Strohmeyer, a German chemist, in 1817 while studying samples of calamine (ZnCO3). When heated, Strohmeyer noticed that some samples of calamine glowed with a yellow color while other samples did not. After further examination, he determined that the calamine that changed color when heated contained trace amounts of a new element. There is only one mineral that contains significant amounts of cadmium, greenockite (CdS), but it is not common enough to mine profitably. Fortunately, small amounts of cadmium are found in zinc ores and most of the cadmium produced today is obtained as a byproduct of mining and refining zinc.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Cadmium is a natural element in the earth's crust. It is usually found as a mineral combined with other elements such as oxygen (cadmium oxide), chlorine (cadmium chloride), or sulfur (cadmium sulfate, cadmium sulfide). All soils and rocks, including coal and mineral fertilizers, contain some cadmium.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
    
</body>
</html>