
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=0.8">
    <link rel="stylesheet" type="text/css" href="infostyle.css?">
    <link rel="stylesheet" href="/webdev/navbar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@600&display=swap" rel="stylesheet">
    <title>TECHNETIUM</title>
    <style>
        .logoutbtn{
            background-color: transparent;
            border: none;
            color: white;
            width: auto;
            font-size: 15px;
            font-family: 'Inter Tight', sans-serif;

        }
        .logoutbtn:hover{
            text-shadow: 0 0 5px #FF0000;
            font-weight: bold;
            border-bottom: 2px solid;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logotitle">
            <a href="/webdev/index.php"><image class="image" src="atom-loader.gif"></a>
            <a href="/webdev/index.php"><h4>THE ELEMENT'S DICTIONARY</h4></a>
        </div>
        <div class="menu">
            <ul>
                <li><a href="/webdev/index.php">Home</a></li>
                <li><a href="/webdev/game.php">Games</a></li>
                <?php if(isset($_SESSION['Id'])) : ?>
                    <li>
                        <form method="post">
                            <button type="submit" name="logoutbtn" class="logoutbtn">LogOut</button>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="profilebox">
                <a href="/webdev/profile.php"><image class="profile" src="user.png"></a>
            </div>
        </div>
    </nav>   
    
        <div class="b-info">
            <span class="l-one">43.</span>
            <span class="r-one">98</span>
            <a class="h" href="https://en.wikipedia.org/wiki/Technetium">Tc</a>

            <hr class="h-line">
            <span class="e-name">TECHNETIUM</span>
            <span class="n-m">(Transition metals)</span>
            <div class="info">
                <span>Atomic mass: 98 u</span>
                <span>Melting point: 2203.85°C (2477 K)</span>
                <span>Boiling point: 4264.85°C (4538 K)</span>
                <span>Discovery date: 1937</span>
                <span>Discovered by: Emilio Segrè, Carlo Perrier</span>
            </div>
        </div>

        <div class="e-info">
            <div class="h-info">
                <span class="first-info">TECHNETIUM</span>
                <span class="first">Technetium is a chemical element with the symbol Tc and atomic number 43.</span>

                <span class="history">HISTORY</span>
                <span class="second">Technetium was the first artificially produced element. It was isolated by Carlo Perrier and Emilio Segrè in 1937. Technetium was created by bombarding molybdenum atoms with deuterons that had been accelerated by a device called a cyclotron. Today, technetium is produced by bombarding molybdenum-98 with neutrons. Molybdenum-98 becomes molybdenum-99 when it captures a neutron. Molybdenum-99, with a half-life of 65.94 hours, decays into technetium-99 through beta decay. While technetium has never been found to occur naturally on earth, its spectral lines have bEen observed in S-, M- and N-type stars.Technetium's most stable isotope, technetium-98, has a half-life of about 4,200,000 years. It decays into ruthenium-98 through beta decay.</span>
                
                <span class="facts">FACTS</span>
                <span class="third">Technetium-99 (Tc-99) is a radioactive metal. Most technetium-99 is produced artificially, but some also occurs naturally in very small amounts in the earth's crust. Technetium-99 was first obtained from the element molybdenum, but it is also produced as a nuclear reactor fission product of uranium and plutonium.</span>
            </div>
        </div>

        <style>
    .b-info .info{line-height: 25px;
        top: 60%;
        height: 30vh;
        position: fixed;
    font-size: 16px}

    </style>
</body>
</html>